import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../utils/fetchWithTimeout', () => ({
  fetchWithTimeout: vi.fn(),
}))

vi.mock('../config', () => ({
  config: {
    fishAudioApiKey: 'test-fish-key',
    fishAudioVoiceId: 'test-voice-id',
  },
}))

import { fetchWithTimeout } from '../utils/fetchWithTimeout'
import { fishAudioService } from './fishAudio'

const mockFetch = vi.mocked(fetchWithTimeout)

describe('fishAudioService', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('synthesize', () => {
    it('should return audio buffer on success', async () => {
      const audioData = Buffer.from('fake-mp3-data')
      mockFetch.mockResolvedValueOnce({
        ok: true,
        arrayBuffer: () => Promise.resolve(audioData.buffer),
      } as Response)

      const result = await fishAudioService.synthesize('你好世界')
      expect(Buffer.isBuffer(result)).toBe(true)
      expect(result.length).toBeGreaterThan(0)

      expect(mockFetch).toHaveBeenCalledWith(
        'https://api.fish.audio/v1/tts',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Authorization': 'Bearer test-fish-key',
          }),
        }),
        30000
      )
    })

    it('should throw on API error', async () => {
      mockFetch.mockResolvedValueOnce({
        ok: false,
        text: () => Promise.resolve('Unauthorized'),
      } as Response)

      await expect(fishAudioService.synthesize('test')).rejects.toThrow('Fish Audio error')
    })

    it('should throw when API key not configured', async () => {
      const origKey = (fishAudioService as any).apiKey
      ;(fishAudioService as any).apiKey = ''

      await expect(fishAudioService.synthesize('test')).rejects.toThrow('FISH_AUDIO_API_KEY not configured')

      ;(fishAudioService as any).apiKey = origKey
    })
  })
})
