import { config } from '../config'
import { fetchWithTimeout } from '../utils/fetchWithTimeout'
import type { TtsEngine } from '../types'

/**
 * Fish Audio TTS 引擎 —— 保留为多引擎体系中的可选引擎。
 * 实现 TtsEngine 接口，可被 registerTtsEngine 注册。
 * 当前未配置 key 时 isReady() 返回 false，会被工厂自动回落到 mimo-tts。
 */
class FishAudioService implements TtsEngine {
  readonly id = 'fish'
  readonly label = 'Fish Audio'
  readonly kind = 'preset' as const

  private apiKey: string
  private voiceId: string

  constructor() {
    this.apiKey = config.fishAudioApiKey
    this.voiceId = config.fishAudioVoiceId
  }

  async isReady(): Promise<boolean> {
    return Boolean(this.apiKey)
  }

  async synthesize(text: string): Promise<Buffer> {
    if (!this.apiKey) {
      throw new Error('FISH_AUDIO_API_KEY not configured')
    }

    const res = await fetchWithTimeout(
      'https://api.fish.audio/v1/tts',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          text,
          reference_id: this.voiceId,
          format: 'mp3',
        }),
      },
      30000 // TTS can take longer
    )

    if (!res.ok) {
      const err = await res.text()
      throw new Error(`Fish Audio error: ${err}`)
    }

    return Buffer.from(await res.arrayBuffer())
  }
}

export const fishAudioService = new FishAudioService()
