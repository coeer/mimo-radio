import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('../utils/fetchWithTimeout', () => ({
  fetchWithTimeout: vi.fn(),
}))

vi.mock('../config', () => ({
  config: {
    feishuAppId: 'test-app-id',
    feishuAppSecret: 'test-app-secret',
  },
}))

import { fetchWithTimeout } from '../utils/fetchWithTimeout'
import { feishuService } from './feishu'

const mockFetch = vi.mocked(fetchWithTimeout)

function mockJsonResponse(data: unknown, ok = true, status = 200) {
  return { ok, status, json: () => Promise.resolve(data), text: () => Promise.resolve(JSON.stringify(data)) } as Response
}

describe('feishuService', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    // Reset internal token cache
    ;(feishuService as any).token = ''
    ;(feishuService as any).tokenExpiry = 0
    ;(feishuService as any).tokenPromise = null
  })

  describe('getTodayEvents', () => {
    it('should return empty array when credentials not configured', async () => {
      const origAppId = (feishuService as any).appId
      const origAppSecret = (feishuService as any).appSecret
      ;(feishuService as any).appId = ''
      ;(feishuService as any).appSecret = ''

      const result = await feishuService.getTodayEvents()
      expect(result).toEqual([])

      ;(feishuService as any).appId = origAppId
      ;(feishuService as any).appSecret = origAppSecret
    })

    it('should fetch and parse calendar events', async () => {
      // Mock token refresh
      mockFetch.mockResolvedValueOnce(
        mockJsonResponse({
          code: 0,
          tenant_access_token: 'test-token',
          expire: 7200,
        })
      )

      // Mock calendar API
      mockFetch.mockResolvedValueOnce(
        mockJsonResponse({
          data: {
            items: [
              {
                summary: '团队周会',
                start_time: { date_time: '2026-05-21T10:00:00+08:00' },
                end_time: { date_time: '2026-05-21T11:00:00+08:00' },
                description: '每周例会',
              },
              {
                summary: '午餐',
                start_time: { date_time: '2026-05-21T12:00:00+08:00' },
                end_time: { date_time: '2026-05-21T13:00:00+08:00' },
              },
            ],
          },
        })
      )

      const events = await feishuService.getTodayEvents()
      expect(events.length).toBe(2)
      expect(events[0].title).toBe('团队周会')
      expect(events[0].startTime).toContain('10:00')
      expect(events[1].title).toBe('午餐')
    })

    it('should return empty on token refresh failure', async () => {
      mockFetch.mockResolvedValueOnce(
        mockJsonResponse({ code: 10003, msg: 'invalid app_id' })
      )

      const events = await feishuService.getTodayEvents()
      expect(events).toEqual([])
    })

    it('should return empty on calendar API failure', async () => {
      // Token success
      mockFetch.mockResolvedValueOnce(
        mockJsonResponse({ code: 0, tenant_access_token: 'token', expire: 7200 })
      )
      // Calendar failure
      mockFetch.mockResolvedValueOnce(
        mockJsonResponse({ error: 'forbidden' }, false, 403)
      )

      const events = await feishuService.getTodayEvents()
      expect(events).toEqual([])
    })
  })
})
