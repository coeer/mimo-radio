import { config } from '../config'
import { CalendarEvent } from '../types'
import { fetchWithTimeout } from '../utils/fetchWithTimeout'
import { logger } from '../utils/logger'

class FeishuService {
  private appId: string
  private appSecret: string
  private token: string = ''
  private tokenExpiry: number = 0
  private tokenPromise: Promise<string> | null = null

  constructor() {
    this.appId = config.feishuAppId
    this.appSecret = config.feishuAppSecret
  }

  private async getToken(): Promise<string> {
    // Return cached token if valid
    if (this.token && Date.now() < this.tokenExpiry) {
      return this.token
    }

    // Prevent concurrent token refresh
    if (this.tokenPromise) {
      return this.tokenPromise
    }

    this.tokenPromise = this.refreshToken()
    try {
      const token = await this.tokenPromise
      return token
    } finally {
      this.tokenPromise = null
    }
  }

  private async refreshToken(): Promise<string> {
    const res = await fetchWithTimeout(
      'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          app_id: this.appId,
          app_secret: this.appSecret,
        }),
      },
      10000
    )

    if (!res.ok) {
      const err = await res.text()
      throw new Error(`Feishu token refresh failed: ${err}`)
    }

    const data = await res.json() as { tenant_access_token?: string; expire?: number; code?: number; msg?: string }
    if (data.code !== 0 || !data.tenant_access_token) {
      throw new Error(`Feishu token refresh failed: ${data.msg || 'unknown error'}`)
    }

    this.token = data.tenant_access_token
    this.tokenExpiry = Date.now() + (data.expire! - 120) * 1000 // Refresh 2 min early
    return this.token
  }

  async getTodayEvents(): Promise<CalendarEvent[]> {
    if (!this.appId || !this.appSecret) {
      return []
    }

    try {
      const token = await this.getToken()
      const today = new Date().toISOString().split('T')[0]
      const start = `${today}T00:00:00+08:00`
      const end = `${today}T23:59:59+08:00`

      const res = await fetchWithTimeout(
        `https://open.feishu.cn/open-apis/calendar/v4/calendars/primary/events?start_time=${encodeURIComponent(start)}&end_time=${encodeURIComponent(end)}`,
        { headers: { 'Authorization': `Bearer ${token}` } },
        15000
      )

      if (!res.ok) {
        logger.warn('Feishu calendar fetch failed', { statusCode: String(res.status) })
        return []
      }

      const data = await res.json() as { data?: { items?: Array<any> } }
      const items = data.data?.items || []

      return items.map((e: any) => ({
        title: e.summary || '无标题',
        startTime: e.start_time?.date_time || e.start_time?.date || '',
        endTime: e.end_time?.date_time || e.end_time?.date || '',
        description: e.description || '',
      }))
    } catch (err) {
      logger.warn('Feishu calendar error', { error: String(err) })
      return []
    }
  }
}

export const feishuService = new FeishuService()
