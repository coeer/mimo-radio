import Database from 'better-sqlite3'
import { join } from 'path'
import { mkdirSync, existsSync } from 'fs'
import { Song, RadioSession, UserProfile } from '../types'
import { logger } from '../utils/logger'

const DATA_DIR = join(__dirname, '../../data')
const DB_PATH = join(DATA_DIR, 'mimo.db')

// Session TTL: 24 hours
const SESSION_TTL_MS = 24 * 60 * 60 * 1000
// Cleanup interval: 1 hour
const CLEANUP_INTERVAL_MS = 60 * 60 * 1000

let db: Database | null = null

function getDb(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initDb() first.')
  }
  return db
}

export function initDb() {
  // Ensure data directory exists before opening database
  if (!existsSync(DATA_DIR)) {
    mkdirSync(DATA_DIR, { recursive: true })
    logger.info('Created data directory', { path: DATA_DIR })
  }

  db = new Database(DB_PATH)
  db.pragma('journal_mode = WAL')

  // Songs table
  db.exec(`
    CREATE TABLE IF NOT EXISTS songs (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL
    )
  `)

  // Sessions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      queue TEXT NOT NULL,
      current_index INTEGER NOT NULL DEFAULT 0,
      dj_enabled INTEGER NOT NULL DEFAULT 1,
      context TEXT NOT NULL,
      messages TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `)

  // Index on updated_at for efficient TTL cleanup queries
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_sessions_updated_at ON sessions(updated_at)
  `)

  // Profile table (single row)
  db.exec(`
    CREATE TABLE IF NOT EXISTS profile (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      data TEXT NOT NULL
    )
  `)

  logger.info('SQLite database initialized')
}

// ─── Songs ───

export function getSongs(): Song[] {
  const rows = getDb().prepare('SELECT data FROM songs').all() as { data: string }[]
  return rows.map((r) => JSON.parse(r.data))
}

export function setSongs(newSongs: Song[]) {
  const db = getDb()
  const insert = db.prepare('INSERT OR REPLACE INTO songs (id, data) VALUES (?, ?)')
  db.transaction(() => {
    db.prepare('DELETE FROM songs').run()
    for (const song of newSongs) {
      insert.run(song.id, JSON.stringify(song))
    }
  })()
}

// ─── Sessions ───

function rowToSession(row: {
  id: string
  queue: string
  current_index: number
  dj_enabled: number
  context: string
  messages: string
  created_at: string
  updated_at: string
}): RadioSession {
  return {
    id: row.id,
    queue: JSON.parse(row.queue),
    currentIndex: row.current_index,
    djEnabled: Boolean(row.dj_enabled),
    context: JSON.parse(row.context),
    messages: JSON.parse(row.messages),
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  }
}

export function getSession(id: string): RadioSession | undefined {
  const row = getDb()
    .prepare('SELECT * FROM sessions WHERE id = ?')
    .get(id) as Parameters<typeof rowToSession>[0] | undefined
  if (!row) return undefined
  return rowToSession(row)
}

export function setSession(id: string, session: RadioSession, refreshUpdatedAt = true) {
  if (refreshUpdatedAt) {
    session.updatedAt = new Date()
  }
  getDb()
    .prepare(
      `INSERT OR REPLACE INTO sessions
       (id, queue, current_index, dj_enabled, context, messages, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      session.id,
      JSON.stringify(session.queue),
      session.currentIndex,
      session.djEnabled ? 1 : 0,
      JSON.stringify(session.context),
      JSON.stringify(session.messages),
      session.createdAt.toISOString(),
      session.updatedAt.toISOString()
    )
}

// ─── Profile ───

export function getProfile(): UserProfile | null {
  const row = getDb().prepare('SELECT data FROM profile WHERE id = 1').get() as { data: string } | undefined
  if (!row) return null
  return JSON.parse(row.data)
}

export function setProfile(p: UserProfile) {
  getDb()
    .prepare('INSERT OR REPLACE INTO profile (id, data) VALUES (1, ?)')
    .run(JSON.stringify(p))
}

// ─── Session TTL & Cleanup ───

function cleanupExpiredSessions(): number {
  const cutoff = new Date(Date.now() - SESSION_TTL_MS).toISOString()
  const result = getDb().prepare('DELETE FROM sessions WHERE updated_at < ?').run(cutoff)
  const removed = result.changes
  if (removed > 0) {
    logger.info(`Cleaned up ${removed} expired sessions`)
  }
  return removed
}

export function checkDbHealth(): boolean {
  try {
    getDb().prepare('SELECT 1').get()
    return true
  } catch {
    return false
  }
}

export function startSessionCleanup(): void {
  cleanupExpiredSessions()
  setInterval(cleanupExpiredSessions, CLEANUP_INTERVAL_MS)
  logger.info('Session cleanup started', { ttlHours: 24 })
}
