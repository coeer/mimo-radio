import { describe, it, expect, beforeEach } from 'vitest'
import {
  initDb,
  getSongs,
  setSongs,
  getSession,
  setSession,
  getProfile,
  setProfile,
  startSessionCleanup,
} from './index'
import type { RadioSession, Song, UserProfile } from '../types'

describe('db', () => {
  beforeEach(() => {
    initDb()
    setSongs([])
  })

  describe('songs', () => {
    it('should get and set songs', () => {
      const songs: Song[] = [
        { id: '1', title: 'Test', artist: 'Artist', emotionTags: ['a'], sceneTags: ['b'] },
      ]
      setSongs(songs)
      expect(getSongs()).toEqual(songs)
    })
  })

  describe('sessions', () => {
    it('should get and set sessions', () => {
      const session: RadioSession = {
        id: 'test-session',
        queue: [],
        currentIndex: 0,
        djEnabled: true,
        context: { time: '12:00' },
        messages: [],
        createdAt: new Date('2026-01-01'),
        updatedAt: new Date('2026-01-01'),
      }
      setSession(session.id, session)
      const retrieved = getSession(session.id)
      expect(retrieved).toBeDefined()
      expect(retrieved!.id).toBe('test-session')
    })

    it('should revive Date objects from storage', () => {
      const session: RadioSession = {
        id: 'date-test',
        queue: [],
        currentIndex: 0,
        djEnabled: true,
        context: { time: '12:00' },
        messages: [],
        createdAt: new Date('2026-01-01'),
        updatedAt: new Date('2026-01-01'),
      }
      setSession(session.id, session)
      const retrieved = getSession(session.id)
      expect(retrieved!.createdAt).toBeInstanceOf(Date)
      expect(retrieved!.updatedAt).toBeInstanceOf(Date)
    })

    it('should update updatedAt on set', () => {
      const session: RadioSession = {
        id: 'update-test',
        queue: [],
        currentIndex: 0,
        djEnabled: true,
        context: { time: '12:00' },
        messages: [],
        createdAt: new Date('2026-01-01'),
        updatedAt: new Date('2026-01-01'),
      }
      setSession(session.id, session)
      const before = getSession(session.id)!.updatedAt.getTime()

      // Wait a tiny bit then update
      return new Promise((resolve) => setTimeout(resolve, 50)).then(() => {
        setSession(session.id, { ...session, updatedAt: new Date() })
        const after = getSession(session.id)!.updatedAt.getTime()
        expect(after).toBeGreaterThanOrEqual(before)
      })
    })
  })

  describe('profile', () => {
    it('should get and set profile', () => {
      const profile: UserProfile = {
        personalityType: '测试型',
        personalityDesc: '测试描述',
        emotionDistribution: { 开心: 5 },
        sceneDistribution: { 工作: 3 },
        favoriteArtists: ['Test'],
        totalSongs: 10,
        totalListenTime: 3600,
      }
      setProfile(profile)
      expect(getProfile()).toEqual(profile)
    })
  })

  describe('session cleanup', () => {
    it('should clean up expired sessions', () => {
      const oldSession: RadioSession = {
        id: 'old',
        queue: [],
        currentIndex: 0,
        djEnabled: true,
        context: { time: '12:00' },
        messages: [],
        createdAt: new Date(Date.now() - 25 * 60 * 60 * 1000), // 25 hours ago
        updatedAt: new Date(Date.now() - 25 * 60 * 60 * 1000),
      }
      const newSession: RadioSession = {
        id: 'new',
        queue: [],
        currentIndex: 0,
        djEnabled: true,
        context: { time: '12:00' },
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      setSession(oldSession.id, oldSession)
      setSession(newSession.id, newSession)

      // setSession updates updatedAt, so manually reset it for the old session
      const storedOld = getSession('old')!
      storedOld.updatedAt = new Date(Date.now() - 25 * 60 * 60 * 1000)
      setSession(storedOld.id, storedOld, false)

      // Manually trigger cleanup
      startSessionCleanup()

      expect(getSession('old')).toBeUndefined()
      expect(getSession('new')).toBeDefined()
    })
  })
})
