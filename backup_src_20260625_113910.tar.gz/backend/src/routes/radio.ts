import { Router } from 'express'
import { randomUUID } from 'crypto'
import { z } from 'zod'
import { Song, ChatMessage } from '../types'
import { createSession, getSongPool, loadMockSongs, loadNeteaseSongs } from '../services/engine'
import { getAIService, listAvailableModels } from '../services/aiFactory'
import { weatherService } from '../services/weather'
import { feishuService } from '../services/feishu'
import { getCurrentPlaylist } from '../services/scheduler'
import { getMusicSource } from '../services/musicSource'
import { personaPromptBlock } from '../services/djPersona'
import { validateBody } from '../middleware/validate'
import { sessionAuth } from '../middleware/sessionAuth'
import { signSession } from '../utils/sessionToken'
import { sanitizePromptInput } from '../utils/promptGuard'
import { logger } from '../utils/logger'
import { setSession, getSession } from '../db'
import { AI_CHAT_HISTORY_LIMIT, AI_MESSAGES_RETURN_LIMIT } from '../constants'

const router = Router()

// Lazy-load mock songs on first request
let songsLoaded = false
function ensureSongsLoaded() {
  if (!songsLoaded) {
    loadMockSongs()
    songsLoaded = true
  }
}

/**
 * 根据 mood 提取搜索关键词（网易云搜索需要明确关键词）
 */
function moodToKeywords(mood?: string): string[] {
  if (!mood) {
    // 默认：兼顾多元品味
    return ['华语流行', 'YOASOBI', '钢琴纯音乐', '深夜']
  }
  const kw = mood.trim()
  // 简单中文关键词直接用，外加两个补充
  return [kw, '流行', '轻音乐']
}

const createSchema = z.object({
  mood: z.string().max(100).optional(),
  dj_enabled: z.boolean().optional(),
  user_input: z.string().max(500).optional(),
  model: z.string().max(50).optional(),
})


const nextBodySchema = z.object({
  model: z.string().max(50).optional(),
})

const chatSchema = z.object({
  text: z.string().min(1).max(2000),
  model: z.string().max(50).optional(),
})

const feedbackSchema = z.object({
  action: z.enum(['skip', 'like', 'complete']),
  reason: z.string().max(500).optional(),
})

// Chat response can include a new song to play
interface RecommendItem {
  title: string
  artist: string
  qqMusicMid?: string
  neteaseId?: string
  selected?: boolean
}

interface ChatResponse {
  reply: string
  action: string | null
  action_data: string | null
  messages: ChatMessage[]
  model: string
  new_song?: Song
  recommendations?: RecommendItem[]
}

// GET /api/radio/models
router.get('/models', (_req, res) => {
  res.json({ models: listAvailableModels() })
})

// POST /api/radio/create
router.post('/create', validateBody(createSchema), async (req, res, next) => {
  try {
    ensureSongsLoaded()
    const { mood, dj_enabled, user_input, model } = req.body

    // 基于用户 mood 用网易云真实搜索构建可播放曲库（替代 MOCK）
    try {
      const keywords = moodToKeywords(user_input || mood)
      await loadNeteaseSongs(keywords)
      songsLoaded = true
    } catch (err) {
      logger.error('网易云曲库加载失败，继续用现有曲库', { error: String(err) })
    }

    const ai = getAIService(model)

    // Gather context in parallel (weather + calendar are independent)
    const [weatherResult, calendarResult] = await Promise.allSettled([
      weatherService.getCurrent(),
      feishuService.getTodayEvents(),
    ])
    const weather = weatherResult.status === 'fulfilled' ? weatherResult.value : undefined
    const calendar = calendarResult.status === 'fulfilled' ? calendarResult.value : undefined
    const now = new Date()
    const timeStr = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`

    // If no mood provided, use current time slot
    let effectiveMood = mood
    let contextMood = mood
    if (!effectiveMood) {
      const current = getCurrentPlaylist()
      if (current) {
        effectiveMood = current.slot.label
        contextMood = current.slot.tags.join('、')
      }
    }

    const context = {
      weather,
      calendar,
      time: timeStr,
      userInput: user_input || effectiveMood,
      mood: contextMood || effectiveMood,
    }

    // Create session
    const session = createSession(effectiveMood, dj_enabled !== false, undefined, context)

    // Generate intro if DJ enabled
    if (session.djEnabled) {
      try {
        const intro = await ai.generateIntro(effectiveMood || '随机', context)
        session.messages.push({
          id: randomUUID(),
          sender: 'kimi',
          text: intro,
          timestamp: 0,
        })
      } catch {
        session.messages.push({
          id: randomUUID(),
          sender: 'kimi',
          text: effectiveMood ? `你好，我为你准备了一些${effectiveMood}氛围的音乐。` : '你好，欢迎收听 MiMo 电台。',
          timestamp: 0,
        })
      }
    }

    setSession(session.id, session)

    res.json({
      session_id: session.id,
      session_token: signSession(session.id),
      queue: session.queue,
      current_song: session.queue[0] || null,
      intro_script: session.messages[0]?.text || null,
      model: ai.model,
    })
  } catch (err) {
    next(err)
  }
})

// POST /api/radio/:id/next
router.post('/:id/next', sessionAuth, validateBody(nextBodySchema), async (req, res, next) => {
  try {
    const { model } = req.body
    const ai = getAIService(model)

    const sessionId = req.sessionId!
    const session = getSession(sessionId)
    if (!session) {
      return res.status(404).json({
        success: false,
        error: { message: 'Session not found', code: 'SESSION_NOT_FOUND' },
      })
    }

    // Bounds check before incrementing
    if (session.currentIndex >= session.queue.length - 1) {
      return res.json({
        song: null,
        transition: null,
        has_more: false,
        model: ai.model,
      })
    }

    session.currentIndex += 1

    // Generate DJ transition
    const prev = session.queue[session.currentIndex - 1] || null
    const next = session.queue[session.currentIndex]
    let transition = null

    if (next && session.djEnabled) {
      try {
        transition = await ai.generateDJTransition(prev, next, session.context)
        session.messages.push({
          id: randomUUID(),
          sender: 'kimi',
          text: transition.text,
          timestamp: 0,
        })
      } catch {
        session.messages.push({
          id: randomUUID(),
          sender: 'kimi',
          text: `接下来是 ${next.artist} 的《${next.title}》。`,
          timestamp: 0,
        })
      }
    }

    setSession(session.id, session)

    res.json({
      song: next || null,
      transition: transition?.text || null,
      has_more: session.currentIndex < session.queue.length - 1,
      model: ai.model,
    })
  } catch (err) {
    next(err)
  }
})

// POST /api/radio/:id/chat
router.post('/:id/chat', sessionAuth, validateBody(chatSchema), async (req, res, next) => {
  try {
    const { text, model } = req.body
    const ai = getAIService(model)

    const sessionId = req.sessionId!
    const session = getSession(sessionId)
    if (!session) {
      return res.status(404).json({
        success: false,
        error: { message: 'Session not found', code: 'SESSION_NOT_FOUND' },
      })
    }

    // Sanitize user input before storage and prompt embedding
    const sanitizedText = sanitizePromptInput(text)

    // Save user message
    session.messages.push({
      id: randomUUID(),
      sender: 'user',
      text: sanitizedText,
      timestamp: 0,
    })

    // Build conversation history for AI
    const history: { role: 'user' | 'assistant'; content: string }[] = session.messages.map(m => ({
      role: (m.sender === 'user' ? 'user' : 'assistant') as 'user' | 'assistant',
      content: m.text,
    }))

    // Current song context
    const currentSong = session.queue[session.currentIndex]
    const songContext = currentSong
      ? `当前正在播放：${currentSong.title} - ${currentSong.artist}（${currentSong.album || '未知专辑'}），标签：${currentSong.emotionTags.join('、')}`
      : '当前没有播放歌曲'

    const systemPrompt = `${personaPromptBlock()}

你正在和用户聊天，同时担任电台 DJ 的角色。
${songContext}

【最重要规则 - 关键词高亮】你的每一句回复，都必须把情绪、氛围、场景类的关键词用双星号 ** 包裹。
示例：
- 好呀，**深夜**的**爵士**最有氛围了，让思绪慢慢**沉淀**。
- 这首**温暖**的歌，陪你度过**宁静**的夜晚。
- 当**疲惫**的时候，听点**治愈**的旋律吧。
每句必须有 1-3 个 ** 标记的关键词，这是强制要求。

用户可能想：
1. 聊天（问候、分享心情）
2. 点歌/换歌（"换一首"、"我想听周杰伦"）
3. 询问当前歌曲信息
4. 让你推荐音乐

请用温暖自然的语气回复，30-80字。

如果是点歌/换歌请求，你有两种方式：
- 从本地曲库换歌：回复中注明[换歌:风格描述]
- 从QQ音乐搜索具体歌曲：回复中注明[QQ音乐:歌曲名或歌手名]

如果是推荐请求，回复中注明[推荐:风格描述]。

当前时间：${session.context.time}
当前天气：${session.context.weather?.description || '未知'}`

    // Wrap user input in isolated delimiters to prevent prompt injection
    const wrappedInput = sanitizePromptInput(text)

    const messages = [
      { role: 'system' as const, content: systemPrompt },
      ...history.slice(-AI_CHAT_HISTORY_LIMIT), // Keep last N messages for context
      { role: 'user' as const, content: wrappedInput },
    ]

    let reply = ''
    try {
      reply = await ai.chat(messages)
    } catch {
      reply = '收到，让我为你调整一下。'
    }

    // Save AI reply
    session.messages.push({
      id: randomUUID(),
      sender: 'kimi',
      text: reply,
      timestamp: 0,
    })

    // Check if user wants to change songs or search QQ Music
    let action: string | null = null
    let actionData: string | null = null
    let newSong: Song | undefined = undefined
    let recommendations: RecommendItem[] | undefined = undefined

    if (reply.includes('[QQ音乐:')) {
      const match = reply.match(/\[QQ音乐:([^\]]+)\]/)
      if (match) {
        action = 'play_qqmusic'
        actionData = match[1]
        // Actually search QQ Music
        try {
          const songs = await getMusicSource().searchPlayable(match[1], 5)
          const playable = songs.find((s) => s.playUrl)
          if (playable) {
            newSong = playable
            // Insert into queue after current song
            session.queue.splice(session.currentIndex + 1, 0, playable)
          }
          // 同时返回结构化推荐卡片（供前端卡片化展示）
          recommendations = songs.slice(0, 5).map((s, i) => ({
            title: s.title,
            artist: s.artist,
            neteaseId: s.neteaseId,
            selected: i === 0 && !!s.playUrl,
          }))
        } catch (err) {
          logger.error('QQ Music search failed', { error: String(err) })
        }
      }
    } else if (reply.includes('[换歌:')) {
      const match = reply.match(/\[换歌:([^\]]+)\]/)
      if (match) {
        action = 'change_songs'
        actionData = match[1]
      }
    } else if (reply.includes('[推荐:')) {
      const match = reply.match(/\[推荐:([^\]]+)\]/)
      if (match) {
        action = 'recommend'
        actionData = match[1]
        // 实际搜索歌曲，返回结构化推荐卡片
        try {
          const songs = await getMusicSource().searchPlayable(match[1], 5)
          recommendations = songs.slice(0, 5).map((s, i) => ({
            title: s.title,
            artist: s.artist,
            neteaseId: s.neteaseId,
            selected: i === 0,
          }))
        } catch (err) {
          logger.error('Recommend search failed', { error: String(err) })
        }
      }
    }

    // 兜底：用户明显想推荐/找歌，但 AI 没输出 [推荐:] 标签时，
    // 用用户原话兜底搜索，保证前端推荐卡片有数据
    if (!recommendations && text && /推荐|来点|来首|找|想听|换.*首/.test(text)) {
      try {
        const songs = await getMusicSource().searchPlayable(text.slice(0, 30), 5)
        if (songs.length > 0) {
          action = action || 'recommend'
          actionData = actionData || text.slice(0, 30)
          recommendations = songs.slice(0, 5).map((s, i) => ({
            title: s.title,
            artist: s.artist,
            neteaseId: s.neteaseId,
            selected: i === 0,
          }))
        }
      } catch (err) {
        logger.error('Fallback recommend search failed', { error: String(err) })
      }
    }

    // Clean up tags from displayed text
    const displayReply = reply.replace(/\[(QQ音乐|换歌|推荐):[^\]]+\]/g, '').trim()
    session.messages[session.messages.length - 1].text = displayReply

    setSession(session.id, session)

    const response: ChatResponse = {
      reply: displayReply,
      action,
      action_data: actionData,
      messages: session.messages.slice(-AI_MESSAGES_RETURN_LIMIT),
      model: ai.model,
    }
    if (newSong) {
      response.new_song = newSong
    }
    if (recommendations && recommendations.length > 0) {
      response.recommendations = recommendations
    }

    res.json(response)
  } catch (err) {
    next(err)
  }
})

// POST /api/radio/:id/feedback
router.post('/:id/feedback', sessionAuth, validateBody(feedbackSchema), (req, res) => {
  const sessionId = req.sessionId!
  const session = getSession(sessionId)
  if (!session) {
    return res.status(404).json({
      success: false,
      error: { message: 'Session not found', code: 'SESSION_NOT_FOUND' },
    })
  }

  const { action, reason } = req.body
  const currentSong = session.queue[session.currentIndex]

  // TODO: persist feedback to user profile / ML training pipeline
  logger.info(`Feedback: ${action} on "${currentSong?.title}"`, { reason: reason || undefined })

  res.json({ ok: true, action, song: currentSong?.title })
})

// GET /api/radio/:id/queue
router.get('/:id/queue', sessionAuth, (req, res) => {
  const sessionId = req.sessionId!
  const session = getSession(sessionId)
  if (!session) {
    return res.status(404).json({
      success: false,
      error: { message: 'Session not found', code: 'SESSION_NOT_FOUND' },
    })
  }

  res.json({
    queue: session.queue.slice(session.currentIndex),
    current_index: session.currentIndex,
  })
})

// GET /api/radio/songs
router.get('/songs', (_req, res) => {
  res.json(getSongPool())
})

export default router
