import { Router } from 'express'
import { z } from 'zod'
import { weatherService } from '../services/weather'
import { feishuService } from '../services/feishu'
import { validateQuery } from '../middleware/validate'

const router = Router()

// All context routes are read-only; minimal validation for query params if added later
const cityQuerySchema = z.object({
  city: z.string().max(50).optional(),
})

// GET /api/context/weather
router.get('/weather', validateQuery(cityQuerySchema), async (_req, res, next) => {
  try {
    const weather = await weatherService.getCurrent()
    res.json(weather)
  } catch (err) {
    next(err)
  }
})

// GET /api/context/calendar
router.get('/calendar', async (_req, res, next) => {
  try {
    const events = await feishuService.getTodayEvents()
    res.json({ events })
  } catch (err) {
    next(err)
  }
})

// GET /api/context/all
router.get('/all', async (_req, res, next) => {
  try {
    const [weather, calendar] = await Promise.all([
      weatherService.getCurrent(),
      feishuService.getTodayEvents(),
    ])

    const now = new Date()
    res.json({
      weather,
      calendar,
      time: `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`,
      date: now.toISOString().split('T')[0],
      weekday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][now.getDay()],
    })
  } catch (err) {
    next(err)
  }
})

export default router
