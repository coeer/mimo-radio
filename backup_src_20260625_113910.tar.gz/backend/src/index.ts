import express from 'express'
import rateLimit from 'express-rate-limit'
import helmet from 'helmet'
import compression from 'compression'
import { startPeriodicCleanup } from './utils/fileCleanup'
import { resolve } from 'path'
import { config } from './config'
import { corsMiddleware } from './middleware/cors'
import { errorHandler } from './middleware/error'
import { apiKeyAuth } from './middleware/auth'
import { requestId } from './middleware/requestId'
import { initDb, startSessionCleanup, checkDbHealth } from './db'
import { logger } from './utils/logger'
import { assertSecretConfigured } from './utils/sessionToken'
import { getCircuitStates } from './utils/fetchWithTimeout'

import radioRoutes from './routes/radio'
import djRoutes from './routes/dj'
import djPersonaRoutes from './routes/djPersona'
import musicSourceRoutes from './routes/musicSource'
import ttsEnginesRoutes from './routes/ttsEngines'
import profileRoutes from './routes/profile'
import importRoutes from './routes/import'
import contextRoutes from './routes/context'
import upnpRoutes from './routes/upnp'
import scheduleRoutes from './routes/schedule'
import qqmusicRoutes from './routes/qqmusic'

const app = express()

// Security headers
app.use(helmet())
app.use(compression())

// Rate limiting — general
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
})

// Rate limiting — AI / expensive endpoints
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'AI generation rate limit exceeded. Please slow down.' },
})

app.use(generalLimiter)

// Middleware
app.use(corsMiddleware)
app.use(requestId)
app.use(express.json({ limit: '1mb' }))
app.use(express.urlencoded({ extended: true, limit: '1mb' }))

// Request logging with correlation ID
app.use((req, res, next) => {
  const start = Date.now()
  const reqId = (req as any).requestId || '-'
  res.on('finish', () => {
    const duration = Date.now() - start
    logger.info(`${req.method} ${req.path}`, {
      requestId: reqId,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip,
    })
  })
  next()
})

// Static files (TTS audio)
app.use('/static', express.static(resolve(process.cwd(), 'static')))

// Health check (public)
app.get('/health', (_req, res) => {
  const health = {
    status: 'ok',
    project: 'MiMo',
    version: '0.1.0',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    services: {
      database: 'unknown' as string,
      circuits: getCircuitStates(),
    },
  }

  if (checkDbHealth()) {
    health.services.database = 'ok'
    res.json(health)
  } else {
    health.status = 'degraded'
    health.services.database = 'error'
    res.status(503).json(health)
  }
})

// Global request timeout (prevent hanging connections) — must be before routes
app.use((req, res, next) => {
  req.setTimeout(30000, () => {
    if (!res.headersSent) {
      res.status(408).json({ success: false, error: { message: 'Request timeout', code: 'REQUEST_TIMEOUT' } })
    }
  })
  next()
})

// API Key auth for all /api/* routes
app.use('/api', apiKeyAuth)

// API routes (versioned: /api/v1/*)
app.use('/api/v1/radio', aiLimiter, radioRoutes)
app.use('/api/v1/dj', aiLimiter, djRoutes)
app.use('/api/v1/dj/persona', djPersonaRoutes)
app.use('/api/v1/music-source', musicSourceRoutes)
app.use('/api/v1/tts-engines', ttsEnginesRoutes)
app.use('/api/v1/profile', profileRoutes)
app.use('/api/v1/import', importRoutes)
app.use('/api/v1/context', contextRoutes)
app.use('/api/v1/upnp', upnpRoutes)
app.use('/api/v1/schedule', scheduleRoutes)
app.use('/api/v1/qqmusic', qqmusicRoutes)

// Error handler (must be last)
app.use(errorHandler)

// Initialize database and validate secrets BEFORE starting the server
assertSecretConfigured()
initDb()

// 启动时加载 DJ 人设（若有）
import { loadPersona } from './services/djPersona'
loadPersona()

// 启动时注册双音源（网易云 + QQ）
import { registerMusicSource } from './services/musicSource'
import { neteaseMusicSource } from './services/neteaseSource'
import { registerQQMusicSource } from './services/qqSource'
registerMusicSource(neteaseMusicSource)
registerQQMusicSource()

// 启动时注册 TTS 引擎（MiMo 预置/设计/复刻 + Fish Audio 兜底）
import { registerTtsEngine, setCurrentTtsEngine } from './services/ttsEngine'
import { mimoPresetTts, mimoDesignTts, mimoCloneTts } from './services/mimoTts'
import { fishAudioService } from './services/fishAudio'
import { config as ttsConfig } from './config'
registerTtsEngine(mimoPresetTts)
registerTtsEngine(mimoDesignTts)
registerTtsEngine(mimoCloneTts)
registerTtsEngine(fishAudioService)
// 应用启动默认引擎（由 .env 的 TTS_ENGINE 控制，默认 mimo-tts）
setCurrentTtsEngine(ttsConfig.ttsEngine)

const PORT = config.port
app.listen(PORT, () => {
  startSessionCleanup()
  startPeriodicCleanup(resolve(process.cwd(), 'static/audio'))
  logger.info('Server started', { port: PORT, env: config.nodeEnv })
})
