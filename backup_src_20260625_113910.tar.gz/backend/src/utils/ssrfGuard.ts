import { URL } from 'url'

const PRIVATE_IP_PATTERNS = [
  /^127\./,
  /^10\./,
  /^172\.(1[6-9]|2[0-9]|3[01])\./,
  /^192\.168\./,
  /^0\./,
  /^169\.254\./,
  /^::1$/,
  /^fc00:/i,
  /^fe80:/i,
]

/**
 * Validate a URL to prevent SSRF attacks.
 * Allows only http/https protocols and rejects private/internal IPs.
 */
export function isSafeUrl(urlString: string): { safe: true } | { safe: false; reason: string } {
  let parsed: URL
  try {
    parsed = new URL(urlString)
  } catch {
    return { safe: false, reason: 'invalid URL format' }
  }

  // Protocol check
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { safe: false, reason: 'only http/https protocols are allowed' }
  }

  // Hostname check (reject IP addresses and localhost variants)
  const hostname = parsed.hostname.toLowerCase()

  // Block localhost names
  if (hostname === 'localhost' || hostname.endsWith('.localhost')) {
    return { safe: false, reason: 'localhost is not allowed' }
  }

  // Block private IP ranges
  for (const pattern of PRIVATE_IP_PATTERNS) {
    if (pattern.test(hostname)) {
      return { safe: false, reason: 'private/internal IP addresses are not allowed' }
    }
  }

  return { safe: true }
}
