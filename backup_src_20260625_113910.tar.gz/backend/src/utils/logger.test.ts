import { describe, it, expect, vi, beforeEach } from 'vitest'
import { logger } from './logger'

describe('logger', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
  })

  describe('log levels', () => {
    it('should call console.debug for debug messages in development', () => {
      const debugSpy = vi.spyOn(console, 'debug').mockImplementation(() => {})
      logger.debug('test debug message')
      expect(debugSpy).toHaveBeenCalled()
      expect(debugSpy.mock.calls[0][0]).toContain('DEBUG')
      expect(debugSpy.mock.calls[0][0]).toContain('test debug message')
    })

    it('should call console.info for info messages', () => {
      const infoSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      logger.info('test info', { key: 'value' })
      expect(infoSpy).toHaveBeenCalled()
      expect(infoSpy.mock.calls[0][0]).toContain('INFO')
      expect(infoSpy.mock.calls[0][0]).toContain('test info')
    })

    it('should call console.warn for warn messages', () => {
      const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
      logger.warn('test warning')
      expect(warnSpy).toHaveBeenCalled()
      expect(warnSpy.mock.calls[0][0]).toContain('WARN')
    })

    it('should call console.error for error messages', () => {
      const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
      logger.error('test error', { code: 500 })
      expect(errorSpy).toHaveBeenCalled()
      expect(errorSpy.mock.calls[0][0]).toContain('ERROR')
      expect(errorSpy.mock.calls[0][0]).toContain('test error')
    })
  })

  describe('format', () => {
    it('should include timestamp in log output', () => {
      const infoSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      logger.info('test')
      expect(infoSpy.mock.calls[0][0]).toMatch(/\d{4}-\d{2}-\d{2}T/)
    })

    it('should include metadata when provided', () => {
      const infoSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      logger.info('test', { requestId: 'abc123' })
      expect(infoSpy.mock.calls[0][0]).toContain('abc123')
    })
  })
})
