import { config } from '../config'

/**
 * Lightweight structured logger.
 *
 * No external dependencies (no Winston/Pino). Outputs JSON in production
 * and human-readable lines in development.
 */

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

const CURRENT_LEVEL = config.nodeEnv === 'production'
  ? LogLevel.INFO
  : LogLevel.DEBUG

function shouldLog(level: LogLevel): boolean {
  return level >= CURRENT_LEVEL
}

function formatLog(
  level: string,
  message: string,
  meta?: Record<string, unknown>
): string {
  const timestamp = new Date().toISOString()
  if (config.nodeEnv === 'production') {
    return JSON.stringify({ timestamp, level, message, ...meta })
  }
  const metaStr = meta ? ' ' + JSON.stringify(meta) : ''
  return `[${timestamp}] ${level}: ${message}${metaStr}`
}

export const logger = {
  debug(message: string, meta?: Record<string, unknown>) {
    if (shouldLog(LogLevel.DEBUG)) {
      console.debug(formatLog('DEBUG', message, meta))
    }
  },

  info(message: string, meta?: Record<string, unknown>) {
    if (shouldLog(LogLevel.INFO)) {
      console.info(formatLog('INFO', message, meta))
    }
  },

  warn(message: string, meta?: Record<string, unknown>) {
    if (shouldLog(LogLevel.WARN)) {
      console.warn(formatLog('WARN', message, meta))
    }
  },

  error(message: string, meta?: Record<string, unknown>) {
    if (shouldLog(LogLevel.ERROR)) {
      console.error(formatLog('ERROR', message, meta))
    }
  },
}
