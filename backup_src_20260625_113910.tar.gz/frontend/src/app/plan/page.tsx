'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import PlanTimeline, { PlanSlot } from '@/components/PlanTimeline'
import { API_BASE, getApiHeaders } from '@/lib/config'

/**
 * /plan 每日电台时间轴页 —— 对齐视频 182-190s
 * 终端启动日志 + 一天时段列表 + 当前时段高亮
 *
 * 数据源：GET /api/v1/schedule/today
 */
export default function PlanPage() {
  const [slots, setSlots] = useState<PlanSlot[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/v1/schedule/today`, {
          headers: getApiHeaders(false),
        })
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const data = await res.json()
        // 后端返回 DailySchedule，转换 slots -> PlanSlot[]
        const raw = data.slots || []
        const playlist = data.playlist || []
        const mapped: PlanSlot[] = raw.map((s: { start: string; end: string; label: string }, i: number) => ({
          start: s.start,
          end: s.end,
          scene: s.label,
          songs: (playlist[i]?.songs || []).slice(0, 3).map((sg: { title: string; artist: string }) => ({
            name: sg.title,
            artist: sg.artist,
          })),
        }))
        setSlots(mapped)
      } catch (e) {
        setError(e instanceof Error ? e.message : '加载失败')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  return (
    <main className="min-h-screen relative overflow-x-hidden bg-[var(--bg-void)]">
      <div className="ambient-glow" />
      <div className="dot-grid" />

      <div className="relative z-10 mx-auto w-full max-w-[440px] px-4 py-6">
        {/* 顶栏 */}
        <div className="flex items-center justify-between mb-6">
          <Link
            href="/"
            className="text-[11px] text-[var(--fg-muted)] font-[var(--font-mono)] hover:text-[var(--fg-primary)] transition-colors"
          >
            ← 返回电台
          </Link>
          <span className="text-[11px] text-[var(--fg-dim)] font-[var(--font-mono)]">PLAN</span>
        </div>

        {/* 标题区 */}
        <div className="text-center mb-5">
          <h1
            className="text-[24px] font-bold"
            style={{ color: 'var(--fg-primary)', fontFamily: 'var(--font-display)' }}
          >
            Claudio 的施工图
          </h1>
          <p className="text-[12px] text-[var(--fg-muted)] mt-1">（截图给 Claude code 看）</p>
          <div className="inline-block mt-3 px-3 py-1 rounded-full text-[10px]"
            style={{
              background: 'var(--bg-elevated)',
              color: 'var(--accent-warm)',
              border: '1px solid var(--surface-border-subtle)',
            }}
          >
            个人AI电台 · Claudio · 读懂听歌习惯 → 规划声音 → 像DJ那样播报
          </div>
        </div>

        {/* 终端日志区 */}
        <div className="terminal-panel mb-5">
          <div className="terminal-line">
            <span style={{ color: 'var(--neon-green)' }}>&gt;</span> claudio start
          </div>
          <div className="terminal-line">
            Claudio Server — listening on :8765
          </div>
          <div className="terminal-line">
            <span style={{ color: 'var(--neon-green)' }}>●</span> connected to 网易云 / Spotify
          </div>
          <div className="terminal-line">
            <span style={{ color: 'var(--neon-green)' }}>●</span> Claudio DJ Taste loaded
          </div>
          <div className="terminal-line">
            <span style={{ color: 'var(--neon-green)' }}>●</span> mmguo 的飞书日程
          </div>
          <div className="terminal-line mt-2" style={{ color: 'var(--fg-primary)' }}>
            Claudio DJ &nbsp;{new Date().toISOString().split('T')[0]} {['周日','周一','周二','周三','周四','周五','周六'][new Date().getDay()]}
          </div>
          <div className="terminal-line">
            正在为你定制今日电台...
          </div>
          <div className="terminal-line mt-1">
            <span style={{ color: 'var(--neon-green)' }}>●</span>{' '}
            <span style={{ color: 'var(--fg-primary)' }}>起床时间：09:12 （周一）</span>
          </div>
          <div className="terminal-line">
            <span style={{ color: 'var(--neon-green)' }}>●</span>{' '}
            <span style={{ color: 'var(--fg-primary)' }}>天气：晴 22/8℃ &nbsp;日落时间 18:56</span>
          </div>
        </div>

        {/* 时间轴列表 */}
        {loading ? (
          <div className="text-center text-[12px] text-[var(--fg-muted)] py-8">
            正在生成今日电台...
          </div>
        ) : error ? (
          <div className="text-center text-[12px] text-[var(--color-error)] py-8">
            加载失败：{error}
          </div>
        ) : (
          <PlanTimeline slots={slots} />
        )}
      </div>
    </main>
  )
}
