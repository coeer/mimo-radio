'use client'

import { useState, useCallback, useEffect } from 'react'
import KimiCard from '@/components/KimiCard'
import DotMatrixClock from '@/components/DotMatrixClock'
import OnAirBadge from '@/components/OnAirBadge'
import QueueList from '@/components/QueueList'
import TerminalLog from '@/components/TerminalLog'
import TopBar from '@/components/TopBar'
import SourceSwitcher from '@/components/SourceSwitcher'
import TtsEngineSwitcher from '@/components/TtsEngineSwitcher'
import FullscreenPlayer from '@/components/FullscreenPlayer'
import ParticleBackground from '@/components/ParticleBackground'
import PlayerBar from '@/components/PlayerBar'
import ChatArea from '@/components/ChatArea'
import InputArea from '@/components/InputArea'
import { useAudioPlayer } from '@/hooks/useAudioPlayer'
import { useSession } from '@/hooks/useSession'
import { useRadioStore } from '@/store/radioStore'
import Link from 'next/link'

export default function Home() {
  const [inputText, setInputText] = useState('')
  const [showTerminal, setShowTerminal] = useState(true)

  const { handleSeek, getFrequencyData } = useAudioPlayer()
  const { createSession, sendChatMessage } = useSession()

  const sessionId = useRadioStore((state) => state.sessionId)
  const currentSong = useRadioStore((state) => state.currentSong)
  const queue = useRadioStore((state) => state.queue)
  const isCreating = useRadioStore((state) => state.isCreating)
  const isPlaying = useRadioStore((state) => state.isPlaying)
  const isOnline = useRadioStore((state) => state.isOnline)
  const isFullscreenPlayer = useRadioStore((state) => state.isFullscreenPlayer)

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return
      switch (e.key) {
        case ' ':
          e.preventDefault()
          useRadioStore.getState().togglePlay()
          break
        case 'ArrowLeft':
          handleSeek(Math.max(0, (useRadioStore.getState().currentTime || 0) - 10))
          break
        case 'ArrowRight':
          handleSeek(Math.min(
            useRadioStore.getState().duration || 0,
            (useRadioStore.getState().currentTime || 0) + 10
          ))
          break
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [handleSeek])

  // 首页加载时自动创建电台会话 —— 让一进来就有播放卡片
  useEffect(() => {
    if (sessionId || isCreating) return
    createSession('深夜想听点安静的')
    setShowTerminal(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // 浏览器自动播放策略：首次用户交互后，恢复被拦截的播放
  // （intro 说完后会 setIsPlaying(true)，但若无真实交互会被 NotAllowedError 拦截）
  useEffect(() => {
    const unlockAudio = () => {
      const s = useRadioStore.getState()
      // 若有歌但没在播（被拦），且 DJ 没在说话，则触发播放
      if (s.currentSong?.playUrl && !s.isPlaying && !s.isSpeaking) {
        s.setIsPlaying(true)
      }
    }
    // 任何用户交互都算"解锁"
    const opts = { once: true }
    window.addEventListener('click', unlockAudio, opts)
    window.addEventListener('keydown', unlockAudio, opts)
    return () => {
      window.removeEventListener('click', unlockAudio)
      window.removeEventListener('keydown', unlockAudio)
    }
  }, [])

  // Network status
  useEffect(() => {
    const handleOnline = () => useRadioStore.getState().setOnline(true)
    const handleOffline = () => useRadioStore.getState().setOnline(false)
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)
    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  const handleSend = useCallback(async () => {
    if (!inputText.trim() || isCreating) return
    const text = inputText.trim()
    const s = useRadioStore.getState()
    s.addMessage({ sender: 'user', text, timestamp: 0 })
    setInputText('')

    if (sessionId) {
      await sendChatMessage(text)
    } else {
      const ok = await createSession(text)
      if (ok) setShowTerminal(false)
    }
  }, [inputText, isCreating, sessionId, sendChatMessage, createSession])

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend()
  }, [handleSend])

  return (
    <>
      {/* 全屏播放器（条件渲染） */}
      {isFullscreenPlayer && <FullscreenPlayer />}

      {/* Skip to content link for keyboard navigation */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:top-4 focus:left-4 focus:px-4 focus:py-2 focus:rounded-lg focus:bg-[var(--bg-surface)] focus:text-[var(--fg-primary)] focus:outline focus:outline-2 focus:outline-[var(--accent-warm)] focus:outline-offset-2"
      >
        跳转到主内容
      </a>
      <main id="main-content" className="min-h-screen relative overflow-x-hidden bg-[var(--bg-void)]">
      <ParticleBackground />
      <div className="ambient-glow" />
      <div className="dot-grid" />

      <div className="relative z-10 mx-auto w-full max-w-[440px] px-4 py-6 flex flex-col gap-3">
        {/* 顶栏：头像+Claudio / DARK-LIGHT 胶囊 */}
        <TopBar />

        {/* 次级导航：音源切换 + TTS 引擎切换 + 进入每日电台 */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <SourceSwitcher />
            <TtsEngineSwitcher />
          </div>
          <Link
            href="/plan"
            className="text-[11px] tracking-wider transition-opacity hover:opacity-70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:opacity-100 focus-visible:outline-[var(--accent-warm)] rounded-sm px-1 py-0.5 text-[var(--fg-muted)] font-[var(--font-mono)]"
          >
            PLAN →
          </Link>
        </div>

        {/* 单列内容流 */}
        {/* Clock + ON AIR */}
        <div className="flex flex-col items-center gap-3">
          <div className="animate-text-glow">
            <DotMatrixClock />
          </div>
          <OnAirBadge isLive={isPlaying} />
        </div>

        {/* Offline indicator */}
        {!isOnline && (
          <div className="rounded-full px-3 py-1.5 text-center text-[11px] bg-[var(--color-error-bg)] text-[var(--color-error)]">
            网络已断开，正在播放本地缓存
          </div>
        )}

        {/* Player Bar (info only) */}
        {sessionId && currentSong && <PlayerBar getFrequencyData={getFrequencyData} />}

        {/* Terminal Log */}
        {showTerminal && !sessionId && (
          <div className="card-enter max-h-[300px] overflow-y-auto rounded-2xl" style={{ scrollbarWidth: 'none' }}>
            <TerminalLog />
          </div>
        )}

        {/* Player Card */}
        {currentSong && (
          <KimiCard onSeek={handleSeek} getFrequencyData={getFrequencyData} />
        )}

        {/* Loading Skeleton */}
        {isCreating && (
          <div className="card-enter">
            <div className="rounded-[16px] p-5 space-y-3 surface-card">
              <div className="flex items-center gap-3">
                <div className="skeleton w-10 h-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="skeleton w-24 h-3" />
                  <div className="skeleton w-16 h-2" />
                </div>
              </div>
              <div className="skeleton w-full h-10 rounded-lg" />
              <div className="flex gap-2">
                <div className="skeleton w-20 h-2" />
                <div className="skeleton w-16 h-2" />
              </div>
            </div>
          </div>
        )}

        {/* Chat Area */}
        <ChatArea />

        {/* Input Area */}
        <InputArea
          inputText={inputText}
          setInputText={setInputText}
          onSend={handleSend}
          onKeyDown={handleKeyDown}
        />

        {/* Queue */}
        {sessionId && queue.length > 0 && (
          <div className="card-enter card-enter-delay-1">
            <QueueList />
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-center gap-3 pb-6">
        <span className="text-[11px] text-[var(--fg-dim)] font-[var(--font-mono)]">CLAUDIO FM</span>
        <span className="w-1 h-1 rounded-full bg-[var(--fg-dim)]" />
        <span className="text-[11px] font-[var(--font-mono)]" style={{ color: isOnline ? 'var(--color-success)' : 'var(--color-error)' }}>
          {isOnline ? 'CONNECTED' : 'OFFLINE'}
        </span>
      </div>
    </main>
  </>
  )
}
