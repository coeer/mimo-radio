'use client'

import { useCallback, useRef } from 'react'
import { useRadioStore } from '@/store/radioStore'
import { API_BASE, getApiHeaders } from '@/lib/config'
import { useTTS } from './useTTS'

export function useSession() {
  const djEnabled = useRadioStore((state) => state.djEnabled)
  const { speak, setHandlers, stop: stopTTS } = useTTS()
  // 防止重复注册 handlers
  const handlersRegistered = useRef(false)
  if (!handlersRegistered.current) {
    /**
     * DJ 解说结束（无论正常结束还是出错）后，自动续播当前歌曲。
     *
     * 不依赖 currentSong.playUrl 是否存在：QQ 等音源的 playUrl 是
     * 由 useAudioPlayer 在 isPlaying=true 后异步获取的，所以这里只要
     * 有 currentSong 就该触发播放，否则会卡在"说完不续播"。
     */
    const resumePlaybackAfterSpeak = () => {
      const s = useRadioStore.getState()
      s.setSpeaking(false)
      s.setAiCurrentTime(0)
      if (s.currentSong && !s.isPlaying) {
        s.setIsPlaying(true)
      }
    }
    setHandlers({
      onStart: () => {
        const s = useRadioStore.getState()
        s.setSpeaking(true)
        s.setAiCurrentTime(0)
      },
      onTimeUpdate: (cur, dur) => {
        const s = useRadioStore.getState()
        s.setAiCurrentTime(cur)
        if (dur > 0) s.setAiVoiceDuration(dur)
      },
      onEnd: () => {
        // 关键：DJ 说完后自动开始播放当前歌曲（intro→歌曲的衔接）
        resumePlaybackAfterSpeak()
      },
      onError: () => {
        // TTS 合成/播放失败也要续播，否则开场白说完（或出错）后永远卡住不续播
        resumePlaybackAfterSpeak()
      },
    })
    handlersRegistered.current = true
  }

  /**
   * 真实合成并播放 AI 语音解说。
   * TTS 的 onEnd 会把 isSpeaking 置 false（替代旧的假 setTimeout）。
   */
  const speakAIMessage = useCallback(
    async (text: string) => {
      if (!text?.trim()) return
      const s = useRadioStore.getState()
      s.setSpeaking(true)
      s.setAiCurrentTime(0)
      try {
        await speak(text)
      } catch (err) {
        console.error('[TTS] speak failed', err)
        s.setSpeaking(false)
      }
    },
    [speak]
  )

  const createSession = useCallback(
    async (text: string) => {
      const s = useRadioStore.getState()
      s.setIsCreating(true)
      s.clearMessages()
      try {
        const res = await fetch(`${API_BASE}/api/v1/radio/create`, {
          method: 'POST',
          headers: getApiHeaders(),
          body: JSON.stringify({
            mood: text,
            dj_enabled: djEnabled,
            user_input: text,
          }),
        })
        if (!res.ok) {
          const errText = await res.text()
          throw new Error(`HTTP ${res.status}: ${errText}`)
        }
        const data = await res.json()
        s.setSessionToken(data.session_token || null)
        s.setSessionId(data.session_id || null)
        s.setQueue(data.queue || [])
        if (data.queue?.length > 0) {
          s.setCurrentSong(data.queue[0])
          s.setDuration(data.queue[0].duration || 180)
          // 注意：不立即 setIsPlaying(true)。
          // 如果有 DJ 开场白，等 TTS 说完（onEnd→isSpeaking=false）再自动放歌；
          // 如果没有开场白，直接放。
          if (!data.intro_script || !djEnabled) {
            s.setIsPlaying(true)
          }
          // 否则：speakAIMessage 的 onEnd 会触发 useAudioPlayer 自动播放
        }
        if (data.intro_script) {
          s.addMessage({
            sender: 'kimi',
            text: data.intro_script,
            timestamp: 0,
          })
          // 真实合成并播放 AI 开场语音（TTS ended 驱动 isSpeaking）
          if (djEnabled) {
            speakAIMessage(data.intro_script)
          } else {
            // DJ 关闭但后端给了 intro，直接放歌
            s.setIsPlaying(true)
          }
        }
        return true
      } catch (err) {
        console.error('[Session] createSession failed:', err)
        s.addMessage({
          sender: 'kimi',
          text: '抱歉，电台启动失败了，请检查后端服务。',
          timestamp: 0,
        })
        return false
      } finally {
        s.setIsCreating(false)
      }
    },
    [djEnabled, speakAIMessage]
  )

  const sendChatMessage = useCallback(
    async (text: string) => {
      const s = useRadioStore.getState()
      const sid = s.sessionId
      if (!sid) return false
      s.setIsCreating(true)
      try {
        const res = await fetch(`${API_BASE}/api/v1/radio/${sid}/chat`, {
          method: 'POST',
          headers: getApiHeaders(),
          body: JSON.stringify({ text, model: s.currentModel, session_token: s.sessionToken }),
        })
        if (!res.ok) {
          const errText = await res.text()
          throw new Error(`HTTP ${res.status}: ${errText}`)
        }
        const data = await res.json()
        if (data.reply) {
          s.addMessage({
            sender: 'kimi',
            text: data.reply,
            timestamp: 0,
            recommendations: data.recommendations || undefined,
          })
          // 真实合成播放 AI 回复语音
          speakAIMessage(data.reply)
        }
        if (data.new_song) {
          const song = data.new_song
          s.setQueue([...s.queue, song])
          s.setCurrentSong(song)
          s.setDuration(song.duration || 180)
          s.setIsPlaying(true)
        }
        return true
      } catch (err) {
        console.error('[Chat] sendChatMessage failed:', err)
        s.addMessage({
          sender: 'kimi',
          text: '网络有点卡，稍后再聊。',
          timestamp: 0,
        })
        return false
      } finally {
        s.setIsCreating(false)
      }
    },
    [speakAIMessage]
  )

  return { createSession, sendChatMessage, speakAIMessage, stopTTS }
}
