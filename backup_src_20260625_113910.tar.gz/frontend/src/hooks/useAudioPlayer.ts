'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useRadioStore } from '@/store/radioStore'
import { useAudioAnalyser } from './useAudioAnalyser'
import { API_BASE, getApiHeaders } from '@/lib/config'

export function useAudioPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const timerRefs = useRef<Set<ReturnType<typeof setTimeout>>>(new Set())
  const { connect: connectAnalyser, getFrequencyData, resume: resumeAnalyser } = useAudioAnalyser()

  const currentSong = useRadioStore((state) => state.currentSong)
  const isPlaying = useRadioStore((state) => state.isPlaying)
  const isSpeaking = useRadioStore((state) => state.isSpeaking)
  const nextSong = useRadioStore((state) => state.nextSong)

  // Effect 1: Audio element setup + 连 analyser
  useEffect(() => {
    if (!currentSong) return
    let cancelled = false
    const setCurrentTime = useRadioStore.getState().setCurrentTime
    const setDuration = useRadioStore.getState().setDuration

    if (!audioRef.current) {
      audioRef.current = new Audio()
    }
    const audio = audioRef.current

    const setupAudio = (playUrl: string) => {
      const onEnded = () => { nextSong().catch(console.error) }
      const onTimeUpdate = () => setCurrentTime(audio.currentTime)
      const onLoadedMetadata = () => setDuration(audio.duration)
      audio.addEventListener('ended', onEnded)
      audio.addEventListener('timeupdate', onTimeUpdate)
      audio.addEventListener('loadedmetadata', onLoadedMetadata)
      if (audio.src !== playUrl) {
        audio.src = playUrl
        audio.load()
      }
      connectAnalyser(audio)
      return () => {
        audio.removeEventListener('ended', onEnded)
        audio.removeEventListener('timeupdate', onTimeUpdate)
        audio.removeEventListener('loadedmetadata', onLoadedMetadata)
      }
    }

    // 有 playUrl 直接用；无则（QQ 延迟获取）调接口拿
    if (currentSong.playUrl) {
      return setupAudio(currentSong.playUrl)
    } else {
      // QQ 音源：点播时通过 webbridge 桥接获取真实 URL
      ;(async () => {
        try {
          const res = await fetch(`${API_BASE}/api/v1/music-source/play-url`, {
            method: 'POST',
            headers: { ...getApiHeaders(false), 'Content-Type': 'application/json' },
            body: JSON.stringify({ songId: currentSong.id }),
          })
          if (!res.ok) {
            console.warn('[Audio] 获取QQ播放URL失败')
            return
          }
          const data = await res.json()
          if (!cancelled && data.url) {
            // 更新 store 的 playUrl
            useRadioStore.getState().setCurrentSong({ ...currentSong, playUrl: data.url })
            setupAudio(data.url)
          }
        } catch (err) {
          console.error('[Audio] play-url 接口失败', err)
        }
      })()
      return () => { cancelled = true }
    }
  }, [currentSong, nextSong, connectAnalyser])

  // Effect 2: Play/pause control
  // 关键：DJ 解说期间（isSpeaking）暂停歌曲，解说结束后自动恢复播放
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || !currentSong?.playUrl) return

    // DJ 正在说话 → 暂停歌曲（避免双音频冲突）
    if (isSpeaking) {
      audio.pause()
      return
    }

    if (isPlaying) {
      // 播放时恢复 AudioContext（autoplay 策略）
      resumeAnalyser()
      audio.play().catch((err) => {
        if (err instanceof DOMException && err.name === 'NotAllowedError') {
          const s = useRadioStore.getState()
          s.addMessage({
            sender: 'kimi',
            text: '请点击页面以启用音频播放',
            timestamp: 0,
          })
          s.setIsPlaying(false)
        }
      })
    } else {
      audio.pause()
    }
  }, [isPlaying, isSpeaking, currentSong, resumeAnalyser])

  // Cleanup on unmount
  useEffect(() => {
    const timers = timerRefs.current
    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ''
        audioRef.current = null
      }
      timers.forEach(clearTimeout)
      timers.clear()
    }
  }, [])

  const handleSeek = useCallback((time: number) => {
    if (audioRef.current) audioRef.current.currentTime = time
  }, [])

  const addTimer = useCallback((callback: () => void, delay: number) => {
    const t: ReturnType<typeof setTimeout> = setTimeout(() => {
      callback()
      timerRefs.current.delete(t)
    }, delay)
    timerRefs.current.add(t)
    return t
  }, [])

  return { audioRef, handleSeek, addTimer, getFrequencyData }
}
