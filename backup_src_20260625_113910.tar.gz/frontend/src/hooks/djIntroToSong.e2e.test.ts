import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useRadioStore } from '@/store/radioStore'
import { useSession } from './useSession'

/**
 * AI DJ「开场白说完→自动放歌」端到端功能性测试
 *
 * 用户报的 bug：
 *   "AIDJ 说完开场白后就没有下文了，期望说完就直接开始放歌曲。"
 *
 * 这套测试真正走完业务链路（而非手写状态断言）：
 *   useSession.createSession()（renderHook 在 React 上下文里调用）
 *     → fetch /radio/create 返回 queue[0]（含 playUrl）+ intro_script
 *     → speakAIMessage(intro) → useTTS.speak()
 *     → fetch /dj/tts 返回 audio_url → HTMLAudioElement 播放
 *     → 播放结束触发 onended → onEnd 回调 → setIsPlaying(true)
 *
 * 这些测试会暴露真实 bug：TTS 出错 / 兜底失败 / 歌曲无 playUrl 时，
 * 开场白"说完"后歌曲永远不会续播。修复前相关场景失败，修复后通过。
 */

// ── Mock fetch（URL 路由式，避免 mockResolvedValueOnce 的顺序依赖）─────
// 不同接口的响应按 URL 关键字分发，create 不会误吞 tts 的 mock。
type RouteResp = { ok: boolean; status?: number; json?: () => Promise<unknown>; text?: () => Promise<string> }
const routes = new Map<string, () => RouteResp>()
const fetchMock = vi.fn(async (url: string) => {
  const u = String(url)
  for (const key of Array.from(routes.keys())) {
    if (u.includes(key)) return routes.get(key)!()
  }
  return { ok: false, status: 404, json: async () => ({}), text: async () => 'not found' }
})
;(globalThis as unknown as { fetch: unknown }).fetch = fetchMock

function route(key: string, resp: RouteResp | (() => RouteResp)) {
  routes.set(key, typeof resp === 'function' ? resp : () => resp)
}
function ttsOk(url = '/static/audio/abc.mp3') {
  route('/dj/tts', {
    ok: true,
    json: async () => ({ audio_url: url, text: 'x', engine: 'mimo-tts' }),
  })
}
function ttsFail() {
  route('/dj/tts', { ok: false, status: 500, json: async () => ({}) })
}

// ── 受控 HTMLAudioElement ───────────────────────────────────
interface MockAudio {
  _src: string
  currentTime: number
  duration: number
  paused: boolean
  play: ReturnType<typeof vi.fn>
  pause: ReturnType<typeof vi.fn>
  load: ReturnType<typeof vi.fn>
  addEventListener: ReturnType<typeof vi.fn>
  removeEventListener: ReturnType<typeof vi.fn>
  onplay: ((...a: unknown[]) => void) | null
  onended: ((...a: unknown[]) => void) | null
  onerror: ((...a: unknown[]) => void) | null
  ontimeupdate: ((...a: unknown[]) => void) | null
  onloadedmetadata: ((...a: unknown[]) => void) | null
}

const audioInstances: MockAudio[] = []

function createAudioMock(): MockAudio {
  const inst: MockAudio = {
    _src: '',
    currentTime: 0,
    duration: 10,
    paused: true,
    play: vi.fn(() => {
      inst.paused = false
      return Promise.resolve()
    }),
    pause: vi.fn(() => {
      inst.paused = true
    }),
    load: vi.fn(),
    // useAudioPlayer 用 addEventListener，useTTS 用 on* 赋值；两者都支持
    addEventListener: vi.fn((type: string, cb: (...args: unknown[]) => void) => {
      ;(inst as unknown as Record<string, unknown>)['on' + type] = cb
    }),
    removeEventListener: vi.fn(),
    onplay: null,
    onended: null,
    onerror: null,
    ontimeupdate: null,
    onloadedmetadata: null,
  }
  Object.defineProperty(inst, 'src', {
    get() {
      return inst._src
    },
    set(v: string) {
      inst._src = v
    },
  })
  return inst
}

// 用真正的 function 构造器：new Audio() 时把创建好的实例「搬」到 this 上，
// 使 this 与 audioInstances[n] 指向同一份对象（事件 onended 等赋值在 this 上，
// 测试要能从 audioInstances[n] 读取并触发）。
// 关键：把 inst 的可枚举属性 + src 访问器都定义到 this，并让两处引用同一个 inst。
let audioImpl: () => MockAudio = createAudioMock

function AudioMockCtor(this: MockAudio) {
  const inst = audioImpl()
  // 把 inst 的全部内容搬到 this（属性值 + 方法）
  for (const key of Object.keys(inst)) {
    ;(this as unknown as Record<string, unknown>)[key] = inst[key as keyof MockAudio]
  }
  // src 访问器：转发到 inst._src
  Object.defineProperty(this, 'src', {
    get: () => inst._src,
    set: (v: string) => {
      inst._src = v
    },
    configurable: true,
  })
  // this 上的 on* 属性变化要同步回 inst，便于测试从 inst 触发；
  // 反过来 inst 的 on* 也代理到 this。直接共享：让两处指向同一组字段。
  syncEventProps(this, inst)
  audioInstances.push(this)
}

// 同步 this 与 inst 的 on* 事件属性（双向代理）
function syncEventProps(target: MockAudio, src: MockAudio) {
  const events = ['onplay', 'onended', 'onerror', 'ontimeupdate', 'onloadedmetadata']
  for (const ev of events) {
    Object.defineProperty(target, ev, {
      get() {
        return src[ev as keyof MockAudio]
      },
      set(v: ((...a: unknown[]) => void) | null) {
        ;(src as unknown as Record<string, unknown>)[ev] = v
      },
      configurable: true,
    })
  }
}

function installAudio() {
  audioInstances.length = 0
  audioImpl = createAudioMock
  ;(globalThis as unknown as { Audio: unknown }).Audio = AudioMockCtor
}

// speechSynthesis 兜底：默认不提供（模拟不可用，强制走真实 audio 或失败）
function removeSpeechSynth() {
  delete (globalThis as unknown as { speechSynthesis?: unknown }).speechSynthesis
}

function resetStore() {
  useRadioStore.getState().clearMessages()
  useRadioStore.setState({
    currentSong: null,
    isPlaying: false,
    isSpeaking: false,
    queue: [],
    aiCurrentTime: 0,
    aiVoiceDuration: 0,
    sessionId: null,
    sessionToken: null,
    isCreating: false,
    djEnabled: true,
  })
}

const SONG = {
  id: 'ne_1',
  title: '夜に駆ける',
  artist: 'YOASOBI',
  playUrl: 'http://m701.music.126.net/test.mp3',
  duration: 200,
  emotionTags: [],
  sceneTags: [],
  platform: 'netease' as const,
}

const SONG_NO_URL = {
  ...SONG,
  id: 'qq_1',
  playUrl: undefined,
  platform: 'qq' as const,
}

// 工具：在 React 上下文里挂载 useSession，返回暴露的 actions
function mountSession() {
  return renderHook(() => useSession())
}

describe('AI DJ 开场白→自动放歌 端到端功能测试', () => {
  let originalAudio: unknown
  let originalSynth: unknown

  beforeEach(() => {
    resetStore()
    fetchMock.mockClear()
    routes.clear()
    removeSpeechSynth()
    originalAudio = (globalThis as unknown as { Audio: unknown }).Audio
    originalSynth = (globalThis as unknown as { speechSynthesis?: unknown }).speechSynthesis
    installAudio()
  })

  afterEach(() => {
    ;(globalThis as unknown as { Audio: unknown }).Audio = originalAudio
    ;(globalThis as unknown as { speechSynthesis?: unknown }).speechSynthesis = originalSynth
    vi.clearAllMocks()
  })

  /**
   * 场景 A（用户最核心诉求）：有开场白，TTS 正常合成并播放完毕 → 必须自动放歌。
   */
  it('场景A：有开场白 + TTS 正常播放完毕 → 自动放歌', async () => {
    // create 返回有歌+开场白
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-1',
        session_token: 'tok-1',
        queue: [SONG],
        intro_script: '晚上好，为你挑了一首适合深夜的歌。',
      }),
    })
    // tts 成功
    ttsOk()

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('深夜想听点安静的')
    })

    const afterCreate = useRadioStore.getState()
    expect(afterCreate.currentSong?.id).toBe('ne_1')
    expect(afterCreate.isSpeaking).toBe(true)
    expect(afterCreate.isPlaying).toBe(false)

    // /dj/tts 被调用
    const ttsCalled = fetchMock.mock.calls.some(([u]) => String(u).includes('/dj/tts'))
    expect(ttsCalled).toBe(true)

    // 至少有一个 Audio 实例（TTS 播放器）
    expect(audioInstances.length).toBeGreaterThanOrEqual(1)
    const ttsAudio = audioInstances[0]
    expect(ttsAudio.play).toHaveBeenCalled()

    // 模拟开场白播放结束
    await act(async () => {
      ttsAudio.onended?.()
    })

    const afterEnd = useRadioStore.getState()
    // ★ 核心断言：说完开场白后自动放歌
    expect(afterEnd.isSpeaking).toBe(false)
    expect(afterEnd.isPlaying).toBe(true)
  })

  /**
   * 场景 B（真实 bug 复现）：有开场白，TTS 音频 play() 失败/出错（autoplay 拦截、解码失败等）。
   * 期望：错误后仍应放歌，而不是永远卡住。
   * 修复前失败（onError 只 setSpeaking(false)），修复后通过。
   */
  it('场景B：有开场白 + TTS 播放出错 → 仍应自动放歌', async () => {
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-2',
        session_token: 'tok-2',
        queue: [SONG],
        intro_script: '晚上好。',
      }),
    })
    ttsOk('/static/audio/bad.mp3')

    // 让本次 Audio 的 play 抛 NotAllowedError（模拟 autoplay 拦截）
    audioImpl = () => {
      const inst = createAudioMock()
      inst.play = vi.fn(() => {
        inst.onerror?.(new Error('TTS audio error'))
        return Promise.reject(new DOMException('NotAllowed', 'NotAllowedError'))
      })
      return inst
    }

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('深夜')
    })
    // flush 微任务，让 play().catch(onError) 跑完
    await act(async () => {
      await Promise.resolve()
      await Promise.resolve()
    })

    const afterError = useRadioStore.getState()
    // ★ TTS 出错后必须放歌，不能卡死
    expect(afterError.isSpeaking).toBe(false)
    expect(afterError.isPlaying).toBe(true)
  })

  /**
   * 场景 C（真实 bug 复现）：有开场白，/dj/tts 失败，且 speechSynthesis 不可用。
   * useTTS 的 onError 被触发。修复后 onError 应续播。
   */
  it('场景C：有开场白 + /dj/tts 失败且 speechSynthesis 不可用 → 应自动放歌', async () => {
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-3',
        session_token: 'tok-3',
        queue: [SONG],
        intro_script: '你好，欢迎收听。',
      }),
    })
    // tts 接口失败
    ttsFail()

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('深夜')
    })
    await act(async () => {
      await Promise.resolve()
      await Promise.resolve()
    })

    const afterError = useRadioStore.getState()
    // ★ 兜底失败也必须放歌
    expect(afterError.isSpeaking).toBe(false)
    expect(afterError.isPlaying).toBe(true)
  })

  /**
   * 场景 D：DJ 关闭（djEnabled=false）但有 intro_script → 直接放歌，不等 TTS。
   */
  it('场景D：DJ 关闭 → 即使有开场白也直接放歌', async () => {
    useRadioStore.getState().setDjEnabled(false)

    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-4',
        session_token: 'tok-4',
        queue: [SONG],
        intro_script: '（后端仍返回了开场白，但前端 DJ 关闭）',
      }),
    })

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('随便')
    })

    const after = useRadioStore.getState()
    expect(after.isPlaying).toBe(true)
    expect(after.isSpeaking).toBe(false)
    // DJ 关闭不调 TTS
    const ttsCalled = fetchMock.mock.calls.some(([u]) => String(u).includes('/dj/tts'))
    expect(ttsCalled).toBe(false)
  })

  /**
   * 场景 E（真实 bug 复现）：歌曲无 playUrl（QQ 音源，异步获取）+ 有开场白。
   * useSession 的 onEnd 里 `if (currentSong?.playUrl && !isPlaying)` 会因 playUrl 为空跳过。
   * 修复后应放歌。
   */
  it('场景E：歌曲无 playUrl（QQ）+ 有开场白说完 → 应放歌', async () => {
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-5',
        session_token: 'tok-5',
        queue: [SONG_NO_URL],
        intro_script: '为你播一首。',
      }),
    })
    ttsOk('/static/audio/e.mp3')

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('深夜')
    })

    const ttsAudio = audioInstances[0]
    await act(async () => {
      ttsAudio.onended?.()
    })

    const after = useRadioStore.getState()
    // ★ 无 playUrl 也要 isPlaying=true（useAudioPlayer 会去拿 url）
    expect(after.isSpeaking).toBe(false)
    expect(after.isPlaying).toBe(true)
  })

  /**
   * 场景 F：无开场白（intro_script 为空）→ 直接放歌，不依赖 TTS。
   */
  it('场景F：无开场白 → createSession 后直接放歌', async () => {
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-6',
        session_token: 'tok-6',
        queue: [SONG],
      }),
    })

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('随便')
    })

    const after = useRadioStore.getState()
    expect(after.isPlaying).toBe(true)
    expect(after.isSpeaking).toBe(false)
  })

  /**
   * 场景 G：开场白说完后歌曲已在播，再次触发 onEnd 不应出错或重置。
   */
  it('场景G：开场白说完但歌曲已在播 → 保持播放状态', async () => {
    route('/radio/create', {
      ok: true,
      json: async () => ({
        session_id: 'sess-7',
        session_token: 'tok-7',
        queue: [SONG],
        intro_script: '嗨。',
      }),
    })
    ttsOk('/static/audio/g.mp3')

    const { result } = mountSession()

    await act(async () => {
      await result.current.createSession('深夜')
    })

    const ttsAudio = audioInstances[0]
    await act(async () => {
      useRadioStore.getState().setIsPlaying(true)
      ttsAudio.onended?.()
    })

    const after = useRadioStore.getState()
    expect(after.isSpeaking).toBe(false)
    expect(after.isPlaying).toBe(true)
  })

  /**
   * 场景 H：/radio/create 本身失败 → 不应崩，给出错误提示。
   */
  it('场景H：create 接口失败 → 状态安全、有错误提示', async () => {
    route('/radio/create', {
      ok: false,
      status: 500,
      json: async () => ({}),
      text: async () => 'Internal Server Error',
    })

    const { result } = mountSession()

    await act(async () => {
      const ok = await result.current.createSession('深夜')
      expect(ok).toBe(false)
    })

    const after = useRadioStore.getState()
    expect(after.isCreating).toBe(false)
    // 错误提示进了消息
    expect(after.messages.length).toBeGreaterThan(0)
    expect(after.messages[0].text).toContain('电台启动失败')
  })
})
