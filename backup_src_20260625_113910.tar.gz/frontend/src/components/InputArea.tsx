'use client'

import React, { memo } from 'react'
import { useRadioStore } from '@/store/radioStore'

interface InputAreaProps {
  inputText: string
  setInputText: (text: string) => void
  onSend: () => void
  onKeyDown: (e: React.KeyboardEvent) => void
}

const InputArea = memo(function InputArea({ inputText, setInputText, onSend, onKeyDown }: InputAreaProps) {
  const isCreating = useRadioStore((state) => state.isCreating)

  return (
    <div>
      <div className="chat-input flex items-center gap-2 px-4 py-2.5">
        <button
          aria-label="Voice input"
          className="w-11 h-11 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 shrink-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent-warm)] text-[var(--fg-muted)]"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />
          </svg>
        </button>
        <input
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={isCreating ? '正在准备电台...' : 'Say something to the DJ...'}
          aria-label="Chat with DJ"
          disabled={isCreating}
          maxLength={500}
          className="flex-1 bg-transparent text-sm outline-none disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-offset-2 rounded-md px-2 py-1 text-[var(--fg-primary)] font-[var(--font-body)] focus-visible:ring-[var(--accent-warm)]"
        />
        <button
          aria-label="Send message"
          onClick={onSend}
          disabled={!inputText.trim() || isCreating}
          className="w-11 h-11 rounded-full flex items-center justify-center transition-all duration-200 disabled:opacity-30 hover:scale-105 active:scale-95 shrink-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent-warm)] bg-[var(--surface-bg-subtle)]"
        >
          {isCreating ? (
            <svg className="w-4 h-4 animate-spin text-[var(--fg-primary)]" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
          ) : (
            <svg className="w-4 h-4 text-[var(--fg-primary)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          )}
        </button>
      </div>
      <div className="flex items-center justify-center gap-4 mt-2">
        <span className="text-[10px] text-[var(--fg-dim)] font-[var(--font-mono)]">Space 播放/暂停</span>
        <span className="text-[10px] text-[var(--fg-dim)] font-[var(--font-mono)]">&larr;&rarr; 快进/快退</span>
      </div>
    </div>
  )
})

export default InputArea
