import { describe, it, expect, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import TypewriterText from './TypewriterText'

describe('TypewriterText', () => {
  it('should render text with typing effect', async () => {
    render(<TypewriterText text="Hello" speed={10} />)

    // Initially only partial text should be visible
    await waitFor(() => {
      expect(screen.getByText('Hello')).toBeInTheDocument()
    })
  })

  it('should call onComplete when typing finishes', async () => {
    const onComplete = vi.fn()
    render(<TypewriterText text="Hi" speed={5} onComplete={onComplete} />)

    await waitFor(() => {
      expect(onComplete).toHaveBeenCalled()
    }, { timeout: 2000 })
  })

  it('should use two spans instead of per-char spans', () => {
    const { container } = render(<TypewriterText text="Hello World" speed={10} />)
    const spans = container.querySelectorAll('span > span')
    // Should have exactly 2 spans (highlight + base), not 11
    expect(spans.length).toBe(2)
  })
})
