'use client'

import React, { memo } from 'react'

export interface PlanSlot {
  start: string  // HH:mm
  end: string
  scene: string
  songs?: { name: string; artist: string }[]
}

interface Props {
  slots: PlanSlot[]
  /** 当前时间 HH:mm，用于高亮当前时段 */
  nowTime?: string
}

function inSlot(start: string, end: string, now: string): boolean {
  // 简单字符串比较，支持跨夜（end < start）
  if (end < start) return now >= start || now < end
  return now >= start && now < end
}

/**
 * 每日电台时间轴列表 —— 对齐视频 182-190s
 * 每行：时间段 + 场景名 + 歌曲（歌名暖铜色）
 * 当前时段绿色左边框高亮
 */
function PlanTimeline({ slots, nowTime }: Props) {
  const now = nowTime || new Date().toTimeString().slice(0, 5)

  return (
    <div className="space-y-1.5">
      {slots.map((slot, i) => {
        const isCurrent = inSlot(slot.start, slot.end, now)
        return (
          <div
            key={i}
            className={`rounded-lg px-3 py-2.5 transition-colors ${
              isCurrent
                ? 'bg-[rgba(0,230,118,0.08)] border-l-2 border-[var(--neon-green)]'
                : 'border-l-2 border-transparent'
            }`}
          >
            <div className="flex items-baseline justify-between gap-3">
              <div className="flex items-baseline gap-2 min-w-0">
                <span
                  className="text-[12px] tabular-nums shrink-0"
                  style={{
                    color: 'var(--fg-secondary)',
                    fontFamily: 'var(--font-mono)',
                  }}
                >
                  {slot.start}-{slot.end}
                </span>
                <span
                  className="text-[13px] font-medium truncate"
                  style={{ color: 'var(--fg-primary)' }}
                >
                  {slot.scene}
                </span>
              </div>
              {isCurrent && (
                <span
                  className="text-[9px] shrink-0 font-[var(--font-mono)]"
                  style={{ color: 'var(--neon-green)' }}
                >
                  ● NOW
                </span>
              )}
            </div>
            {slot.songs && slot.songs.length > 0 && (
              <div className="mt-1 ml-[88px] space-y-0.5">
                {slot.songs.map((s, j) => (
                  <div
                    key={j}
                    className="text-[11px]"
                    style={{ color: 'var(--fg-muted)' }}
                  >
                    <span style={{ color: 'var(--accent-warm)' }}>{s.name}</span>
                    <span style={{ color: 'var(--fg-muted)' }}> — {s.artist}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default memo(PlanTimeline)
