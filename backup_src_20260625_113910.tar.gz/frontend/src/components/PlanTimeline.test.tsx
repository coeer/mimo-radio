import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import PlanTimeline from './PlanTimeline'

const slots = [
  { start: '09:00', end: '12:00', scene: '深度工作', songs: [{ name: 'A Walk', artist: 'Tycho' }] },
  { start: '12:00', end: '14:00', scene: '午休', songs: [] },
  { start: '14:00', end: '18:00', scene: '运动', songs: [{ name: 'A Moment Apart', artist: 'ODESZA' }] },
]

describe('PlanTimeline', () => {
  it('应渲染所有时段', () => {
    render(<PlanTimeline slots={slots} nowTime="08:00" />)
    expect(screen.getByText('深度工作')).toBeInTheDocument()
    expect(screen.getByText('午休')).toBeInTheDocument()
    expect(screen.getByText('运动')).toBeInTheDocument()
  })

  it('应渲染时间段', () => {
    render(<PlanTimeline slots={slots} nowTime="08:00" />)
    expect(screen.getByText('09:00-12:00')).toBeInTheDocument()
    expect(screen.getByText('12:00-14:00')).toBeInTheDocument()
  })

  it('应在当前时段显示 NOW 标记', () => {
    render(<PlanTimeline slots={slots} nowTime="13:00" />)
    // 13:00 落在 12:00-14:00 午休
    expect(screen.getByText('● NOW')).toBeInTheDocument()
  })

  it('当前时段不在任何 slot 时不应显示 NOW', () => {
    render(<PlanTimeline slots={slots} nowTime="08:00" />)
    // 08:00 在所有 slot 之前
    expect(screen.queryByText('● NOW')).not.toBeInTheDocument()
  })

  it('应渲染歌曲（歌名+歌手）', () => {
    render(<PlanTimeline slots={slots} nowTime="08:00" />)
    expect(screen.getByText('A Walk')).toBeInTheDocument()
    // 歌手名（正则匹配，避免破折号前缀 normalize 问题）
    expect(screen.getByText(/Tycho/)).toBeInTheDocument()
  })

  it('无歌曲的时段不应崩溃', () => {
    render(<PlanTimeline slots={slots} nowTime="08:00" />)
    // 午休无 songs，应正常渲染场景名
    expect(screen.getByText('午休')).toBeInTheDocument()
  })

  it('空 slots 不应崩溃', () => {
    const { container } = render(<PlanTimeline slots={[]} nowTime="12:00" />)
    expect(container.firstChild).toBeInTheDocument()
  })

  it('跨夜时段（end < start）应正确判定', () => {
    const overnight = [
      { start: '22:00', end: '02:00', scene: '深夜', songs: [] },
      { start: '09:00', end: '12:00', scene: '白天', songs: [] },
    ]
    // 23:00 应落在跨夜深夜段
    const { rerender } = render(<PlanTimeline slots={overnight} nowTime="23:00" />)
    expect(screen.getByText('● NOW')).toBeInTheDocument()
    // 01:00 也应落在跨夜段
    rerender(<PlanTimeline slots={overnight} nowTime="01:00" />)
    expect(screen.getByText('● NOW')).toBeInTheDocument()
  })
})
