'use client'

import React, { memo, useEffect, useState } from 'react'
import { useRadioStore } from '@/store/radioStore'
import { fmtTime } from '@/lib/utils'
import AudioWaveform from './AudioWaveform'
import { useLyricHighlight } from '@/hooks/useLyricHighlight'
import SpeakingParticles from './SpeakingParticles'

/**
 * 全屏播放器（浅色主题）
 * 对应视频 0-4s / 204-248s：大歌名 + 波形 + 歌词逐句高亮 + Speaking 状态
 *
 * 进入时强制浅色主题，退出恢复用户原主题。
 */
function FullscreenPlayer() {
  const currentSong = useRadioStore((s) => s.currentSong)
  const isPlaying = useRadioStore((s) => s.isPlaying)
  const isSpeaking = useRadioStore((s) => s.isSpeaking)
  const currentTime = useRadioStore((s) => s.currentTime)
  const duration = useRadioStore((s) => s.duration)
  // 歌词高亮改用 AI 语音进度驱动（而非歌曲进度）
  const aiCurrentTime = useRadioStore((s) => s.aiCurrentTime)
  const aiVoiceDuration = useRadioStore((s) => s.aiVoiceDuration)
  const togglePlay = useRadioStore((s) => s.togglePlay)
  const setCurrentTime = useRadioStore((s) => s.setCurrentTime)
  const setFullscreenPlayer = useRadioStore((s) => s.setFullscreenPlayer)
  const nextSong = useRadioStore((s) => s.nextSong)
  const prevSong = useRadioStore((s) => s.prevSong)
  const messages = useRadioStore((s) => s.messages)

  // 进入/退出时切换主题
  const [prevTheme, setPrevTheme] = useState<string>('dark')
  useEffect(() => {
    const root = document.documentElement
    const cur = root.getAttribute('data-theme') || 'dark'
    setPrevTheme(cur)
    root.setAttribute('data-theme', 'light')
    return () => {
      root.setAttribute('data-theme', prevTheme)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // 取最近的 DJ 串词作为歌词源（来自最后一条 kimi 消息）
  const lastDJMessage = [...messages].reverse().find((m) => m.sender === 'kimi')
  const script = lastDJMessage?.text || ''

  const { lines, currentIndex, renderLine, speaker } = useLyricHighlight({
    script,
    // 歌词进度用 AI 语音时长（Speaking 时），否则用歌曲进度
    currentTime: isSpeaking ? aiCurrentTime : currentTime,
    duration: isSpeaking
      ? aiVoiceDuration || (duration || 60)
      : duration || currentSong?.duration || 60,
    isPlaying: isSpeaking || isPlaying,
  })

  // ESC 关闭
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setFullscreenPlayer(false)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [setFullscreenPlayer])

  if (!currentSong) return null

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  // 艺术化大歌名：若歌曲有特殊"电台主题名"用 title，否则用歌名
  const displayTitle = currentSong.title

  return (
    <div className="fullscreen-player fs-enter" role="dialog" aria-label="全屏播放器">
      {/* Speaking 紫蓝粒子背景 */}
      <SpeakingParticles active={isSpeaking} />

      {/* ─── 顶部状态栏 ─── */}
      <div className="flex items-center justify-between px-5 pt-5 pb-2 shrink-0">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #c9a87c 0%, #b07d5a 100%)',
              }}
              aria-hidden="true"
            >
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.348 14.652a3.75 3.75 0 010-5.304m5.304 0a3.75 3.75 0 010 5.304m-7.425 2.121a6.75 6.75 0 010-9.546m9.546 0a6.75 6.75 0 010 9.546M5.106 18.894c-3.808-3.807-3.808-9.98 0-13.788m13.788 0c3.808 3.807 3.808 9.98 0 13.788M12 12h.008v.008H12V12z" />
              </svg>
            </div>
            <span className="text-[15px] font-medium text-[#1a1a1a]" style={{ fontFamily: 'var(--font-display)' }}>
              Claudio
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{
                backgroundColor: '#00c853',
                animation: isSpeaking || isPlaying ? 'pulse-dot 2s ease-in-out infinite' : 'none',
              }}
            />
            <span className="text-[11px] text-[#00c853]">
              {isSpeaking ? 'Speaking...' : isPlaying ? 'On Air' : 'Paused'}
            </span>
          </div>
        </div>
        <button
          onClick={() => setFullscreenPlayer(false)}
          aria-label="收起播放器"
          className="w-9 h-9 rounded-full flex items-center justify-center text-[#666] hover:bg-black/5 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 13H5m0 0l6 6m-6-6l6-6" />
          </svg>
        </button>
      </div>

      {/* ─── 大波形 ─── */}
      <div className="px-5 py-3 shrink-0">
        <AudioWaveform
          isPlaying={isPlaying || isSpeaking}
          barCount={72}
          color="#1a1a1a"
          height={90}
          variant="large"
        />
      </div>

      {/* ─── 歌曲信息 + 进度 ─── */}
      <div className="px-5 pb-3 shrink-0">
        <h1
          className="text-[32px] font-bold leading-tight tracking-tight text-[#1a1a1a]"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          {displayTitle}
        </h1>
        <p className="text-[14px] text-[#666] mt-1">
          {currentSong.artist}
          {currentSong.album ? ` — ${currentSong.album}` : ''}
        </p>

        <div className="flex items-center gap-3 mt-4">
          <button
            onClick={prevSong}
            aria-label="上一首"
            className="w-8 h-8 flex items-center justify-center text-[#1a1a1a] hover:scale-110 transition-transform"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
            </svg>
          </button>
          <button
            onClick={togglePlay}
            aria-label={isPlaying ? '暂停' : '播放'}
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#1a1a1a] hover:bg-black/5 transition-colors"
          >
            {isPlaying ? (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <rect x="6" y="4" width="4" height="16" rx="1" />
                <rect x="14" y="4" width="4" height="16" rx="1" />
              </svg>
            ) : (
              <svg className="w-6 h-6 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>
          <button
            onClick={() => nextSong().catch(console.error)}
            aria-label="下一首"
            className="w-8 h-8 flex items-center justify-center text-[#1a1a1a] hover:scale-110 transition-transform"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" />
            </svg>
          </button>

          <div
            className="flex-1 h-[3px] rounded-full bg-[#e0e0e0] relative cursor-pointer"
            onClick={(e) => {
              const r = e.currentTarget.getBoundingClientRect()
              const p = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width))
              const t = p * duration
              setCurrentTime(t)
            }}
            role="slider"
            tabIndex={0}
            aria-label="进度"
            aria-valuemin={0}
            aria-valuemax={duration}
            aria-valuenow={currentTime}
          >
            <div
              className="h-full rounded-full bg-[#1a1a1a] transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-[11px] tabular-nums text-[#666]" style={{ fontFamily: 'var(--font-mono)' }}>
            {fmtTime(currentTime)} / {fmtTime(duration || 180)}
          </span>
        </div>
      </div>

      {/* ─── 歌词/解说区 ─── */}
      <div className="flex-1 overflow-y-auto px-5 py-3" style={{ scrollbarWidth: 'thin' }}>
        {lines.length > 0 ? (
          lines.map((line, i) => (
            <div key={line.id} className="mb-4">
              {i === currentIndex && (
                <div className="lyric-timestamp">
                  {speaker} • {fmtTime(line.startTime)}
                </div>
              )}
              <p className={`lyric-line ${i === currentIndex ? 'is-current' : ''}`}>
                {renderLine(line).map((seg, j) => (
                  <span key={j} className={seg.isKeyword ? 'lyric-keyword' : ''}>
                    {seg.text}
                  </span>
                ))}
              </p>
            </div>
          ))
        ) : (
          <div className="text-center text-[#999] text-[13px] py-10">
            这首歌还没有 DJ 解说
          </div>
        )}
      </div>

      {/* ─── 底部控制栏 ─── */}
      <div className="flex items-center justify-between px-5 pb-6 pt-2 shrink-0 border-t border-black/5">
        <span className="text-[11px] tabular-nums text-[#666]" style={{ fontFamily: 'var(--font-mono)' }}>
          {fmtTime(currentTime)}
        </span>
        <div className="w-32">
          <AudioWaveform
            isPlaying={isPlaying}
            barCount={24}
            color="#999999"
            height={20}
            variant="mini"
          />
        </div>
        <button
          onClick={togglePlay}
          aria-label={isPlaying ? '暂停' : '播放'}
          className="w-9 h-9 rounded-full bg-[#1a1a1a] flex items-center justify-center text-white hover:scale-105 transition-transform"
        >
          {isPlaying ? (
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <rect x="6" y="4" width="4" height="16" rx="1" />
              <rect x="14" y="4" width="4" height="16" rx="1" />
            </svg>
          ) : (
            <svg className="w-4 h-4 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          )}
        </button>
      </div>
    </div>
  )
}

export default memo(FullscreenPlayer)
