import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import TopBar from './TopBar'

describe('TopBar', () => {
  afterEach(() => {
    document.documentElement.removeAttribute('data-theme')
  })

  it('应显示头像和 Claudio 名称', () => {
    render(<TopBar />)
    expect(screen.getByText('Claudio')).toBeInTheDocument()
  })

  it('应显示 DARK/LIGHT 切换胶囊', () => {
    render(<TopBar />)
    expect(screen.getByText('DARK')).toBeInTheDocument()
    expect(screen.getByText('LIGHT')).toBeInTheDocument()
  })

  it('点击 LIGHT 应切换到浅色主题', () => {
    render(<TopBar />)
    fireEvent.click(screen.getByText('LIGHT'))
    expect(document.documentElement.getAttribute('data-theme')).toBe('light')
  })

  it('点击 DARK 应切换到深色主题', () => {
    render(<TopBar />)
    fireEvent.click(screen.getByText('DARK'))
    expect(document.documentElement.getAttribute('data-theme')).toBe('dark')
  })

  it('头像应是跳转 profile 的链接', () => {
    render(<TopBar />)
    const link = screen.getByRole('link')
    expect(link.getAttribute('href')).toBe('/profile')
  })
})
