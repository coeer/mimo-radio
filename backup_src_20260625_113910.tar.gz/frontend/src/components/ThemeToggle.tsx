'use client'

import { useEffect, useState } from 'react'

export default function ThemeToggle() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  useEffect(() => {
    try {
      const saved = localStorage.getItem('mimo-theme') as 'dark' | 'light' | null
      const initial = saved || 'dark'
      setTheme(initial)
      document.documentElement.setAttribute('data-theme', initial)
    } catch {
      document.documentElement.setAttribute('data-theme', 'dark')
    }
  }, [])

  const toggle = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    document.documentElement.setAttribute('data-theme', next)
    try {
      localStorage.setItem('mimo-theme', next)
    } catch {
      // Safari private mode or quota exceeded — ignore
    }
    const meta = document.getElementById('theme-color-meta') as HTMLMetaElement | null
    if (meta) {
      meta.setAttribute('content', next === 'light' ? '#f5f3ef' : '#06060a')
    }
  }

  return (
    <button
      onClick={toggle}
      aria-pressed={theme === 'dark'}
      aria-label="Toggle theme"
      className="flex items-center gap-1 px-3 py-1.5 rounded-full text-[11px] transition-all duration-200 hover:scale-[1.02] focus-visible:outline-2 focus-visible:outline-offset-2"
      style={{
        background: 'var(--surface-bg-subtle)',
        border: '1px solid var(--surface-border-subtle)',
        color: 'var(--fg-muted)',
        fontFamily: 'var(--font-mono)',
        outlineColor: 'var(--accent-warm)',
      }}
    >
      <span
        className={`px-2 py-0.5 rounded-full transition-all duration-200 ${
          theme === 'dark'
            ? 'bg-white/10 text-white'
            : 'text-black/30'
        }`}
      >
        DARK
      </span>
      <span
        className={`px-2 py-0.5 rounded-full transition-all duration-200 ${
          theme === 'light'
            ? 'bg-black/10'
            : 'text-white/40'
        }`}
        style={{ color: theme === 'light' ? 'var(--fg-primary)' : 'rgba(255,255,255,0.4)' }}
      >
        LIGHT
      </span>
    </button>
  )
}
