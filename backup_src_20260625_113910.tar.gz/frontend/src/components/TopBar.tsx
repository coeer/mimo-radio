'use client'

import React, { memo, useEffect, useState } from 'react'
import Link from 'next/link'

/**
 * 顶栏 —— 对齐视频规格
 * 左：[头像] Claudio（点击进 /profile）
 * 右：DARK/LIGHT 胶囊切换
 */
function TopBar() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  useEffect(() => {
    const cur = document.documentElement.getAttribute('data-theme') as 'dark' | 'light' | null
    if (cur) setTheme(cur)
  }, [])

  const switchTheme = (t: 'dark' | 'light') => {
    setTheme(t)
    document.documentElement.setAttribute('data-theme', t)
    try {
      localStorage.setItem('theme', t)
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="flex items-center justify-between">
      <Link href="/profile" className="flex items-center gap-2 group">
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center transition-transform group-hover:scale-105"
          style={{
            background: 'linear-gradient(135deg, var(--accent-warm) 0%, var(--accent-copper) 100%)',
            boxShadow: '0 0 12px var(--accent-glow)',
          }}
          aria-hidden="true"
        >
          <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.348 14.652a3.75 3.75 0 010-5.304m5.304 0a3.75 3.75 0 010 5.304m-7.425 2.121a6.75 6.75 0 010-9.546m9.546 0a6.75 6.75 0 010 9.546M5.106 18.894c-3.808-3.807-3.808-9.98 0-13.788m13.788 0c3.808 3.807 3.808 9.98 0 13.788M12 12h.008v.008H12V12z" />
          </svg>
        </div>
        <span
          className="text-[14px] font-medium"
          style={{ fontFamily: 'var(--font-display)', color: 'var(--fg-primary)' }}
        >
          Claudio
        </span>
      </Link>

      <div className="flex items-center gap-3">
        <div className="pill-toggle">
          <button
            className={theme === 'dark' ? 'is-active' : ''}
            onClick={() => switchTheme('dark')}
          >
            DARK
          </button>
          <button
            className={theme === 'light' ? 'is-active' : ''}
            onClick={() => switchTheme('light')}
          >
            LIGHT
          </button>
        </div>
      </div>
    </div>
  )
}

export default memo(TopBar)
