'use client'

import { useEffect, useRef, useState } from 'react'

interface TypewriterTextProps {
  text: string
  speed?: number
  highlightColor?: string
  baseColor?: string
  className?: string
  onComplete?: () => void
}

export default function TypewriterText({
  text,
  speed = 40,
  highlightColor = 'var(--accent-warm)',
  baseColor = 'var(--fg-secondary)',
  className = '',
  onComplete,
}: TypewriterTextProps) {
  const [visibleChars, setVisibleChars] = useState(0)
  const onCompleteRef = useRef(onComplete)
  useEffect(() => { onCompleteRef.current = onComplete }, [onComplete])

  useEffect(() => {
    setVisibleChars(0)
    let current = 0
    const timer = setInterval(() => {
      current += 1
      setVisibleChars(current)
      if (current >= text.length) {
        clearInterval(timer)
        onCompleteRef.current?.()
      }
    }, speed)
    return () => clearInterval(timer)
  }, [text, speed])

  return (
    <span className={className}>
      <span style={{ color: highlightColor }}>{text.slice(0, visibleChars)}</span>
      <span style={{ color: baseColor }}>{text.slice(visibleChars)}</span>
    </span>
  )
}
