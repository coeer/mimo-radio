import { create, StateCreator } from 'zustand'
import { devtools, persist } from 'zustand/middleware'
import { API_BASE, getApiHeaders } from '@/lib/config'

// API 类型单一来源：见 @/types/api（与后端 backend/src/types/index.ts 对齐）
export type { MusicPlatform, Song, ChatMessage, RecommendSong } from '@/types/api'
// 本文件内部直接引用，避免循环依赖的具名导入
import type { Song, ChatMessage } from '@/types/api'

// ── Slice types ──────────────────────────────────────────────

interface PlayerSlice {
  currentSong: Song | null
  queue: Song[]
  isPlaying: boolean
  currentTime: number
  duration: number
  isFullscreenPlayer: boolean
  likedSongIds: string[]
  setCurrentSong: (song: Song | null) => void
  setQueue: (queue: Song[]) => void
  togglePlay: () => void
  setIsPlaying: (playing: boolean) => void
  setCurrentTime: (time: number | ((prev: number) => number)) => void
  setDuration: (duration: number) => void
  setFullscreenPlayer: (v: boolean) => void
  toggleLike: (id: string) => void
  isLiked: (id: string) => boolean
}

interface SessionSlice {
  sessionId: string | null
  sessionToken: string | null
  djEnabled: boolean
  currentModel: string
  setSessionId: (id: string | null) => void
  setSessionToken: (token: string | null) => void
  setDjEnabled: (enabled: boolean) => void
  setCurrentModel: (model: string) => void
}

interface ChatSlice {
  messages: ChatMessage[]
  isSpeaking: boolean
  /** AI 语音已播放时长（秒）—— 歌词高亮以此驱动 */
  aiCurrentTime: number
  /** AI 语音总时长（秒） */
  aiVoiceDuration: number
  addMessage: (msg: Omit<ChatMessage, 'id'>) => void
  setSpeaking: (speaking: boolean) => void
  setAiCurrentTime: (t: number) => void
  setAiVoiceDuration: (t: number) => void
  clearMessages: () => void
}

interface StatusSlice {
  isCreating: boolean
  isOnline: boolean
  setIsCreating: (creating: boolean) => void
  setOnline: (online: boolean) => void
}

interface RadioActions {
  nextSong: () => Promise<void>
  prevSong: () => void
}

type RadioState = PlayerSlice & SessionSlice & ChatSlice & StatusSlice & RadioActions

// ── Slice creators ───────────────────────────────────────────
// Each slice declares devtools mutator so `set` accepts the action name arg.
// The devtools + persist middlewares are applied at the combined store level.

type Mutators = [['zustand/devtools', never]]

const createPlayerSlice: StateCreator<
  RadioState,
  Mutators,
  [],
  PlayerSlice
> = (set, get) => ({
  currentSong: null,
  queue: [],
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  isFullscreenPlayer: false,
  likedSongIds: [],
  setCurrentSong: (song) => set({ currentSong: song }, false, 'player/setCurrentSong'),
  setQueue: (queue) => set({ queue }, false, 'player/setQueue'),
  togglePlay: () => set((s) => ({ isPlaying: !s.isPlaying }), false, 'player/togglePlay'),
  setIsPlaying: (playing) => set({ isPlaying: playing }, false, 'player/setIsPlaying'),
  setCurrentTime: (time) =>
    set(
      (s) => ({
        currentTime: typeof time === 'function' ? (time as (prev: number) => number)(s.currentTime) : time,
      }),
      false,
      'player/setCurrentTime',
    ),
  setDuration: (duration) => set({ duration }, false, 'player/setDuration'),
  setFullscreenPlayer: (v) => set({ isFullscreenPlayer: v }, false, 'player/setFullscreenPlayer'),
  toggleLike: (id) =>
    set(
      (s) => ({
        likedSongIds: s.likedSongIds.includes(id)
          ? s.likedSongIds.filter((x) => x !== id)
          : [...s.likedSongIds, id],
      }),
      false,
      'player/toggleLike',
    ),
  isLiked: (id) => get().likedSongIds.includes(id),
})

const createSessionSlice: StateCreator<
  RadioState,
  Mutators,
  [],
  SessionSlice
> = (set) => ({
  sessionId: null,
  sessionToken: null,
  djEnabled: true,
  currentModel: 'mimo-v2.5',
  setSessionId: (id) => set({ sessionId: id }, false, 'session/setSessionId'),
  setSessionToken: (token) => set({ sessionToken: token }, false, 'session/setSessionToken'),
  setDjEnabled: (enabled) => set({ djEnabled: enabled }, false, 'session/setDjEnabled'),
  setCurrentModel: (model) => set({ currentModel: model }, false, 'session/setCurrentModel'),
})

const createChatSlice: StateCreator<
  RadioState,
  Mutators,
  [],
  ChatSlice
> = (set) => ({
  messages: [],
  isSpeaking: false,
  aiCurrentTime: 0,
  aiVoiceDuration: 0,
  addMessage: (msg) =>
    set(
      (s) => ({
        messages: [...s.messages, { ...msg, id: crypto.randomUUID() }],
      }),
      false,
      'chat/addMessage',
    ),
  setSpeaking: (speaking) => set({ isSpeaking: speaking }, false, 'chat/setSpeaking'),
  setAiCurrentTime: (t) => set({ aiCurrentTime: t }, false, 'chat/setAiCurrentTime'),
  setAiVoiceDuration: (t) => set({ aiVoiceDuration: t }, false, 'chat/setAiVoiceDuration'),
  clearMessages: () => set({ messages: [] }, false, 'chat/clearMessages'),
})

const createStatusSlice: StateCreator<
  RadioState,
  Mutators,
  [],
  StatusSlice
> = (set) => ({
  isCreating: false,
  isOnline: true,
  setIsCreating: (creating) => set({ isCreating: creating }, false, 'status/setIsCreating'),
  setOnline: (online) => set({ isOnline: online }, false, 'status/setOnline'),
})

const createRadioActionsSlice: StateCreator<
  RadioState,
  Mutators,
  [],
  RadioActions
> = (_set, get) => ({
  prevSong: () => {
    const { queue, currentSong } = get()
    const currentIndex = queue.findIndex((s) => s.id === currentSong?.id)
    const prev = queue[currentIndex - 1]
    if (prev) {
      _set({ currentSong: prev, currentTime: 0, isPlaying: true }, false, 'radio/prevSong')
    }
  },
  nextSong: async () => {
    const { sessionId, sessionToken } = get()

    if (sessionId) {
      try {
        const res = await fetch(`${API_BASE}/api/v1/radio/${sessionId}/next`, {
          method: 'POST',
          headers: getApiHeaders(),
          body: JSON.stringify({ session_token: sessionToken }),
        })
        if (!res.ok) {
          const errText = await res.text()
          throw new Error(`HTTP ${res.status}: ${errText}`)
        }
        const data = await res.json()

        if (data.song) {
          // Batch all state updates into a single setState call
          const { queue, addMessage } = get()
          const updates: Partial<RadioState> = {
            currentSong: data.song,
            currentTime: 0,
            isPlaying: true,
          }
          if (!queue.find((s) => s.id === data.song.id)) {
            updates.queue = [...queue, data.song]
          }
          _set(updates, false, 'radio/nextSong')

          if (data.transition) {
            addMessage({ sender: 'kimi', text: data.transition, timestamp: 0 })
          }
        }
      } catch (err) {
        console.error('[Store] nextSong API failed:', err)
        const { queue, currentSong } = get()
        const currentIndex = queue.findIndex((s) => s.id === currentSong?.id)
        const next = queue[currentIndex + 1]
        if (next) {
          _set(
            { currentSong: next, currentTime: 0, isPlaying: true },
            false,
            'radio/nextSong/fallback',
          )
        }
      }
    } else {
      const { queue, currentSong } = get()
      const currentIndex = queue.findIndex((s) => s.id === currentSong?.id)
      const next = queue[currentIndex + 1]
      if (next) {
        _set(
          { currentSong: next, currentTime: 0 },
          false,
          'radio/nextSong/local',
        )
      }
    }
  },
})

// ── Compose store ────────────────────────────────────────────

export const useRadioStore = create<RadioState>()(
  devtools(
    persist(
      (...args) => ({
        ...createPlayerSlice(...args),
        ...createSessionSlice(...args),
        ...createChatSlice(...args),
        ...createStatusSlice(...args),
        ...createRadioActionsSlice(...args),
      }),
      {
        name: 'mimo-radio-store',
        // Only persist session fields — player/chat state should reset on reload
        partialize: (state) => ({
          sessionId: state.sessionId,
          sessionToken: state.sessionToken,
          djEnabled: state.djEnabled,
          currentModel: state.currentModel,
        }),
      },
    ),
    { name: 'MimoRadio' },
  ),
)
