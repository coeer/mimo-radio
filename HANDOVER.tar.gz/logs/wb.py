"""mimo-radio 自测 webbridge 封装。
用法: python wb.py <action> [json_args_file_or_inline]
所有命令带固定 session=mimo-radio-selftest。
"""
import sys, json, subprocess, tempfile, os, uuid

DAEMON = "http://127.0.0.1:10086/command"
SESSION = "mimo-radio-selftest"

def call(action, args=None):
    body = {"action": action, "args": args or {}, "session": SESSION}
    # 用唯一临时文件避免 Windows 中文/并发问题
    fd, path = tempfile.mkstemp(suffix=".json", prefix="wb-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(body, f, ensure_ascii=False)
        r = subprocess.run(
            ["curl.exe", "-s", "-m", "20", "-X", "POST", DAEMON,
             "-H", "Content-Type: application/json",
             "--data-binary", f"@{path}"],
            capture_output=True, text=True, timeout=25
        )
        try:
            return json.loads(r.stdout)
        except Exception:
            return {"raw": r.stdout[:300]}
    finally:
        try: os.unlink(path)
        except: pass

if __name__ == "__main__":
    action = sys.argv[1]
    args = {}
    if len(sys.argv) > 2:
        # 第二参数可以是 JSON 字符串或文件路径
        a = sys.argv[2]
        if os.path.exists(a):
            with open(a, encoding="utf-8") as f:
                args = json.load(f)
        else:
            args = json.loads(a)
    result = call(action, args)
    # 紧凑输出，截图类只打印关键字段
    if action == "screenshot":
        print(json.dumps(result.get("data", {}), ensure_ascii=False)[:200])
    elif action == "snapshot":
        d = result.get("data", {})
        print("URL:", d.get("url"))
        def walk(n, depth=0, out=[]):
            if isinstance(n, dict):
                r = n.get("role", ""); name = n.get("name", ""); ref = n.get("ref", "")
                if name and r in ("button", "link", "textbox", "slider", "heading", "StaticText", "dialog") and depth < 4:
                    out.append("  " * depth + r + ": " + str(name)[:42] + (" " + ref if ref else ""))
                for c in n.get("children", []): walk(c, depth + 1, out)
            elif isinstance(n, list):
                for c in n: walk(c, depth, out)
            return out
        o = []; walk(d.get("tree", []), 0, o)
        print("\n".join(o[:35]))
    else:
        print(json.dumps(result.get("data", result), ensure_ascii=False)[:300])
