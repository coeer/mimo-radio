"""R2+R3 真实用户随机点击序列。
刷新前端 → 等会话 → 7步深度交互 → 3步破坏性操作。
每步打印 zustand store 关键状态，检测状态不一致。
"""
import sys, os, time, re, json
sys.path.insert(0, os.path.dirname(__file__))
from wb import call

def state():
    code = ("(()=>{try{var raw=localStorage.getItem('mimo-radio-store')||'{}';"
            "var s=JSON.parse(raw).state||JSON.parse(raw);"
            "return JSON.stringify({cur:(s.currentSong||{}).title?((s.currentSong||{}).title).slice(0,10):null,"
            "liked:(s.likedSongIds||[]).length,play:s.isPlaying,speak:s.isSpeaking,"
            "qLen:(s.queue||[]).length,vol:s.volume,full:s.isFullscreenPlayer})}"
            "catch(e){return 'ERR:'+e.message}})()")
    r = call("evaluate", {"code": code})
    return r.get("data", {}).get("value", "?")[:130]

def snap_refs():
    s = call("snapshot")
    txt = json.dumps(s, ensure_ascii=False)
    refs = {}
    for m in re.finditer(r'"role":"button","name":"([^"]{1,20})","ref":"(@e\d+)"', txt):
        refs[m.group(1)] = m.group(2)
    return refs

print("=== 刷新前端，等会话建立 ===")
call("navigate", {"url": "http://localhost:3000"})
time.sleep(10)  # 等 createSession + 网易云加载
print("会话后:", state())

print("\n=== R2 深度交互 ===")
refs = snap_refs()
print("可用按钮:", list(refs.keys())[:12])

# 1. 暂停
for k in ["Pause","暂停"]:
    if k in refs:
        call("click", {"selector": refs[k]}); time.sleep(1.5)
        print(f"[暂停 {k}]", state()); break

# 2. 播放
for k in ["Play","播放"]:
    if k in refs:
        call("click", {"selector": refs[k]}); time.sleep(2)
        print(f"[播放 {k}]", state()); break

# 3. 收藏
if "收藏" in refs:
    call("click", {"selector": refs["收藏"]}); time.sleep(1)
    print("[收藏]", state())
    # 4. 取消收藏
    call("click", {"selector": refs["收藏"]}); time.sleep(1)
    print("[取消收藏]", state())

# 5. 下一首
if "下一首" in refs:
    call("click", {"selector": refs["下一首"]}); time.sleep(4)
    print("[下一首]", state())

# 6. 全屏
if "展开全屏播放器" in refs:
    call("click", {"selector": refs["展开全屏播放器"]}); time.sleep(2)
    print("[开全屏]", state())
    # 全屏内找收起
    r2 = snap_refs()
    for k in ["收起播放器","收起"]:
        if k in r2:
            call("click", {"selector": r2[k]}); time.sleep(1.5)
            print("[关全屏]", state()); break

print("\n=== R3 破坏性操作 ===")
# 7. 快速连点下一首 3 次（测竞态）
if "下一首" in refs:
    print("[连点下一首 x3 开始]", state())
    for _ in range(3):
        call("click", {"selector": refs["下一首"]})
    time.sleep(6)
    print("[连点后]", state())

# 8. 音量拖动（如果有）
r3 = snap_refs()
if "音量" in r3:
    call("click", {"selector": r3["音量"]}); time.sleep(1)
    print("[点音量]", state())

print("\n=== 完成 ===")
